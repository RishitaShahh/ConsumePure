<?php
require_once "config/database.php";
session_start();

// Check if the user is logged in, if not redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

$search_query = "";
$search_results = array();

if(isset($_GET["query"])){
    $search_query = trim($_GET["query"]);
    
    if(!empty($search_query)){
        // Save search history if user is logged in
        if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
            $sql = "INSERT INTO search_history (user_id, search_term) VALUES (?, ?)";
            if($stmt = mysqli_prepare($conn, $sql)){
                mysqli_stmt_bind_param($stmt, "is", $_SESSION["id"], $search_query);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }
        }
        
        // Search in medicines table
        $sql = "SELECT DISTINCT m.* FROM medicines m 
                WHERE m.name LIKE ? OR 
                m.description LIKE ?
                ORDER BY m.name ASC";
                
        if($stmt = mysqli_prepare($conn, $sql)){
            $search_param = "%" . $search_query . "%";
            mysqli_stmt_bind_param($stmt, "ss", $search_param, $search_param);
            
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
                
                while($row = mysqli_fetch_array($result)){
                    $search_results[] = $row;
                }
            }
            mysqli_stmt_close($stmt);
        }
    }
}
?>

<?php include 'includes/header.php'; ?>

<main class="search-container">
    <div class="search-section">
        <div class="search-header text-center mb-5">
            <h1 class="display-4 fw-bold text-primary">Search Medicines</h1>
            <p class="lead text-muted">Find detailed information about any medicine</p>
        </div>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="GET" class="search-form">
            <div class="search-wrapper">
            <input type="text" name="query" id="medicineSearch" class="search-input" 
                   placeholder="Enter medicine name, description, or manufacturer..." 
                   value="<?php echo htmlspecialchars($search_query); ?>" required>
                <button type="submit" class="search-button">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </form>
        
        <div id="searchResults" class="results-container">
            <?php if(!empty($search_query)): ?>
                <div class="results-header">
                    <h2 class="h3 mb-4">Search Results for "<?php echo htmlspecialchars($search_query); ?>"</h2>
                </div>
                
                <?php if(empty($search_results)): ?>
                    <div class="no-results">
                        <i class="fas fa-search fa-3x mb-3"></i>
                        <h3 class="h4">No medicines found</h3>
                        <p class="text-muted">Try adjusting your search terms</p>
                    </div>
                <?php else: ?>
                    <div class="results-grid">
                        <?php foreach($search_results as $medicine): ?>
                            <div class="medicine-card">
                                <div class="card-content">
                                    <h3 class="medicine-name"><?php echo htmlspecialchars($medicine['name']); ?></h3>
                                    <p class="medicine-description"><?php echo substr(htmlspecialchars($medicine['description']), 0, 150) . '...'; ?></p>
                                <a href="medicine-details.php?id=<?php echo $medicine['id']; ?>" 
                                       class="view-details-btn">
                                    View Details
                                        <i class="fas fa-arrow-right ms-2"></i>
                                </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</main>

<style>
    .search-container {
        padding: 4rem 0;
        background: #f8f9fa;
        min-height: calc(100vh - 60px);
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .search-section {
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 1rem;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .search-header {
        margin-bottom: 3rem;
        text-align: center;
        width: 100%;
    }

    .search-form {
        width: 100%;
        max-width: 800px;
        margin: 0 auto 2rem;
    }

    .search-wrapper {
        display: flex;
        background: white;
        border-radius: 50px;
        padding: 0.5rem;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        width: 100%;
    }

    .search-input {
        flex: 1;
        border: none;
        padding: 1rem 1.5rem;
        font-size: 1.1rem;
        border-radius: 50px 0 0 50px;
        outline: none;
        color: #2c3e50;
    }

    .search-button {
        background: #4a90e2;
        color: white;
        border: none;
        padding: 1rem 2rem;
        border-radius: 50px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .search-button:hover {
        background: #357abd;
    }

    .results-container {
        margin-top: 3rem;
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .results-header {
        text-align: center;
        margin-bottom: 2rem;
        width: 100%;
    }

    .no-results {
        text-align: center;
        padding: 3rem;
        background: white;
        border-radius: 15px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        width: 100%;
        max-width: 600px;
    }

    .no-results i {
        color: #dee2e6;
    }

    .results-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 2rem;
        width: 100%;
    }

    .medicine-card {
        background: white;
        border-radius: 15px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        height: 100%;
    }

    .medicine-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .card-content {
        padding: 2rem;
        height: 100%;
        display: flex;
        flex-direction: column;
    }

    .medicine-name {
        font-size: 1.5rem;
        margin-bottom: 1rem;
        color: #2c3e50;
    }

    .medicine-description {
        color: #4a6b8a;
        margin-bottom: 1.5rem;
        line-height: 1.6;
        flex-grow: 1;
    }

    .view-details-btn {
        display: inline-flex;
        align-items: center;
        background: #4a90e2;
        color: white;
        padding: 0.75rem 1.5rem;
        border-radius: 50px;
        text-decoration: none;
        font-weight: 500;
        transition: all 0.3s ease;
        margin-top: auto;
    }

    .view-details-btn:hover {
        background: #357abd;
        color: white;
        transform: translateX(5px);
    }

    .view-details-btn i {
        transition: transform 0.3s ease;
    }

    .view-details-btn:hover i {
        transform: translateX(5px);
    }

    @media (max-width: 768px) {
        .search-container {
            padding: 2rem 0;
        }

        .search-header {
            margin-bottom: 2rem;
        }

        .search-wrapper {
            flex-direction: column;
            border-radius: 15px;
        }

        .search-input {
            border-radius: 15px 15px 0 0;
        }

        .search-button {
            border-radius: 0 0 15px 15px;
        }

        .results-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('medicineSearch');
    const searchButton = document.querySelector('.search-button');
    
    // Add focus effect to search input
    searchInput.addEventListener('focus', function() {
        this.parentElement.style.boxShadow = '0 4px 20px rgba(74, 144, 226, 0.2)';
    });
    
    searchInput.addEventListener('blur', function() {
        this.parentElement.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.05)';
    });

    // Add animation to medicine cards
    const medicineCards = document.querySelectorAll('.medicine-card');
    medicineCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.3s ease';
        
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
});
</script>

<?php include 'includes/footer.php'; ?> 