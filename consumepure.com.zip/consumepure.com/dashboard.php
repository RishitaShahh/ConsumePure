<?php
require_once "config/database.php";
session_start();

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Initialize arrays
$recent_searches = array();
$recent_chats = array();

// Check if search_history table exists
$table_check = mysqli_query($conn, "SHOW TABLES LIKE 'search_history'");
if(mysqli_num_rows($table_check) > 0) {
    // Get recent searches
    $sql = "SELECT * FROM search_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 5";
    if($stmt = mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, "i", $_SESSION["id"]);
        
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
            
            while($row = mysqli_fetch_array($result)){
                $recent_searches[] = $row;
            }
        }
        mysqli_stmt_close($stmt);
    }
}

// Get recent chat messages from medical_chat_conversations table
$sql = "SELECT * FROM medical_chat_conversations WHERE user_id = ? ORDER BY timestamp DESC LIMIT 5";
if($stmt = mysqli_prepare($conn, $sql)){
    mysqli_stmt_bind_param($stmt, "i", $_SESSION["id"]);
    
    if(mysqli_stmt_execute($stmt)){
        $result = mysqli_stmt_get_result($stmt);
        
        while($row = mysqli_fetch_array($result)){
            $recent_chats[] = $row;
        }
    }
    mysqli_stmt_close($stmt);
}
?>

<?php include 'includes/header.php'; ?>

<main class="dashboard-container">
    <div class="dashboard-welcome text-center mb-5">
        <h1 class="display-4 fw-bold text-primary">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></h1>
        <p class="lead text-muted">Manage your medicine information and chat history here.</p>
    </div>

    <div class="dashboard-grid">
        <!-- Recent Searches Card -->
        <div class="dashboard-card">
            <div class="card-header bg-light-blue">
                <div class="d-flex align-items-center">
                    <i class="fas fa-search me-2"></i>
                    <h2 class="h4 mb-0">Recent Searches</h2>
                </div>
            </div>
            <div class="card-body">
                <?php if(empty($recent_searches)): ?>
                    <div class="empty-state">
                        <i class="fas fa-search fa-2x mb-3"></i>
                        <p class="text-muted">No recent searches found.</p>
                    </div>
                <?php else: ?>
                    <ul class="list-unstyled mb-0">
                        <?php foreach($recent_searches as $search): ?>
                            <li class="search-item">
                                <div class="search-content">
                                    <span class="search-term"><?php echo htmlspecialchars($search['search_term']); ?></span>
                                    <small class="text-muted">
                                        <i class="far fa-clock me-1"></i>
                                        <?php echo date('M j, Y g:i A', strtotime($search['created_at'])); ?>
                                    </small>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Chats Card -->
        <div class="dashboard-card">
            <div class="card-header bg-light-blue">
                <div class="d-flex align-items-center">
                    <i class="fas fa-comments me-2"></i>
                    <h2 class="h4 mb-0">Recent Chats</h2>
                </div>
            </div>
            <div class="card-body">
                <?php if(empty($recent_chats)): ?>
                    <div class="empty-state">
                        <i class="fas fa-comments fa-2x mb-3"></i>
                        <p class="text-muted">No recent chats found.</p>
                    </div>
                <?php else: ?>
                    <ul class="list-unstyled mb-0">
                        <?php foreach($recent_chats as $chat): ?>
                            <li class="chat-item">
                                <div class="chat-message user-message">
                                    <div class="message-content">
                                        <strong>You:</strong> <?php echo htmlspecialchars($chat['user_message']); ?>
                                    </div>
                                </div>
                                <div class="chat-message bot-message">
                                    <div class="message-content">
                                        <strong>Bot:</strong> <?php echo htmlspecialchars(substr($chat['bot_response'], 0, 100)) . (strlen($chat['bot_response']) > 100 ? '...' : ''); ?>
                                    </div>
                                </div>
                                <small class="text-muted chat-time">
                                    <i class="far fa-clock me-1"></i>
                                    <?php echo date('M j, Y g:i A', strtotime($chat['timestamp'])); ?>
                                </small>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<style>
    .dashboard-container {
        padding: 4rem 0;
        background: #f8f9fa;
        min-height: calc(100vh - 60px);
    }

    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 2rem;
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 1rem;
    }

    .dashboard-card {
        background: white;
        border-radius: 15px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .dashboard-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .card-header {
        padding: 1.25rem;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }

    .card-header i {
        color: #4a90e2;
    }

    .card-body {
        padding: 1.25rem;
    }

    .search-item, .chat-item {
        padding: 1rem 0;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }

    .search-item:last-child, .chat-item:last-child {
        border-bottom: none;
    }

    .search-content {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .search-term {
        font-weight: 500;
        color: #2c3e50;
    }

    .chat-message {
        padding: 0.75rem;
        border-radius: 10px;
        margin-bottom: 0.5rem;
    }

    .user-message {
        background: #e6f2ff;
        margin-right: 2rem;
    }

    .bot-message {
        background: #f8f9fa;
        margin-left: 2rem;
    }

    .message-content {
        color: #2c3e50;
    }

    .chat-time {
        display: block;
        margin-top: 0.5rem;
        text-align: right;
    }

    .empty-state {
        text-align: center;
        padding: 2rem;
        color: #6c757d;
    }

    .empty-state i {
        color: #dee2e6;
    }

    .bg-light-blue {
        background: #e6f2ff;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add hover effect to cards
    const cards = document.querySelectorAll('.dashboard-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Add animation to chat messages
    const chatMessages = document.querySelectorAll('.chat-message');
    chatMessages.forEach((message, index) => {
        message.style.opacity = '0';
        message.style.transform = 'translateY(20px)';
        message.style.transition = 'all 0.3s ease';
        
        setTimeout(() => {
            message.style.opacity = '1';
            message.style.transform = 'translateY(0)';
        }, index * 100);
    });
});
</script>

<?php include 'includes/footer.php'; ?> 