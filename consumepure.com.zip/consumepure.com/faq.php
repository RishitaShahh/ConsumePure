<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ - ConsumePure</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-text: #2c3e50;
            --light-text: #7f8c8d;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .faq-container {
            max-width: 900px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .faq-header {
            text-align: center;
            margin-bottom: 3rem;
            position: relative;
        }

        .faq-header h1 {
            color: var(--primary-color);
            font-weight: 700;
            margin-bottom: 1rem;
            position: relative;
            display: inline-block;
        }

        .faq-header h1:after {
            content: '';
            position: absolute;
            width: 50%;
            height: 3px;
            background: var(--secondary-color);
            bottom: -10px;
            left: 25%;
            border-radius: 3px;
        }

        .faq-header p {
            color: var(--light-text);
            font-size: 1.1rem;
        }

        .category-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            justify-content: center;
            margin-bottom: 3rem;
        }

        .category-btn {
            padding: 0.8rem 1.5rem;
            border: 2px solid var(--secondary-color);
            background: none;
            color: var(--secondary-color);
            border-radius: 30px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.9rem;
            letter-spacing: 0.5px;
        }

        .category-btn:hover {
            background: var(--secondary-color);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(52, 152, 219, 0.2);
        }

        .category-btn.active {
            background: var(--secondary-color);
            color: white;
            box-shadow: 0 4px 8px rgba(52, 152, 219, 0.2);
        }

        .faq-item {
            margin-bottom: 1.5rem;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            background: white;
        }

        .faq-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }

        .faq-question {
            background: white;
            padding: 1.5rem;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.3s ease;
        }

        .faq-question:hover {
            background: var(--light-bg);
        }

        .faq-question h3 {
            margin: 0;
            font-size: 1.1rem;
            color: var(--dark-text);
            font-weight: 600;
        }

        .faq-answer {
            background: var(--light-bg);
            padding: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.5s ease;
        }

        .faq-item.active .faq-answer {
            padding: 1.5rem;
            max-height: 500px;
        }

        .answer-content {
            color: var(--light-text);
            line-height: 1.6;
        }

        .answer-content ul {
            padding-left: 1.5rem;
            margin-top: 1rem;
        }

        .answer-content li {
            margin-bottom: 0.5rem;
            position: relative;
        }

        .answer-content li:before {
            content: '•';
            color: var(--secondary-color);
            font-weight: bold;
            position: absolute;
            left: -1rem;
        }

        .toggle-icon {
            color: var(--secondary-color);
            transition: transform 0.3s ease;
        }

        .faq-item.active .toggle-icon {
            transform: rotate(180deg);
        }

        .contact-support {
            text-align: center;
            margin-top: 3rem;
            padding-top: 2rem;
            border-top: 1px solid rgba(0,0,0,0.1);
        }

        .contact-support .btn {
            padding: 0.8rem 2rem;
            border-radius: 30px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }

        .contact-support .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        @media (max-width: 768px) {
            .faq-container {
                margin: 1rem;
                padding: 1.5rem;
            }

            .category-buttons {
                gap: 0.5rem;
            }

            .category-btn {
                padding: 0.6rem 1rem;
                font-size: 0.8rem;
            }

            .faq-question {
                padding: 1rem;
            }

            .faq-question h3 {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="faq-container">
        <div class="faq-section">
            <div class="faq-header text-center mb-5">
                <h1 class="display-4 fw-bold text-primary">Frequently Asked Questions</h1>
                <p class="lead text-muted">Find answers to common questions about our health products and services</p>
            </div>

            <div class="faq-categories mb-4">
                <div class="category-buttons">
                    <button class="category-btn active" data-category="all">All</button>
                    <button class="category-btn" data-category="general">General Health</button>
                    <button class="category-btn" data-category="treatment">Treatment</button>
                    <button class="category-btn" data-category="safety">Safety</button>
                    <button class="category-btn" data-category="consultation">Consultation</button>
                </div>
            </div>

            <div class="faq-accordion">
                <!-- General Health -->
                <div class="faq-item" data-category="general">
                    <div class="faq-question">
                        <h3 class="question-text">What health conditions do you treat?</h3>
                        <span class="toggle-icon">
                            <i class="fas fa-chevron-down"></i>
                        </span>
                    </div>
                    <div class="faq-answer">
                        <div class="answer-content">
                            Our medical team specializes in treating a wide range of health conditions including chronic diseases, acute illnesses, and preventive care. We provide comprehensive care for conditions such as diabetes, hypertension, respiratory disorders, and various other medical conditions. Each treatment plan is personalized to meet your specific health needs.
                        </div>
                    </div>
                </div>

                <div class="faq-item" data-category="general">
                    <div class="faq-question">
                        <h3 class="question-text">How do I prepare for my first medical consultation?</h3>
                        <span class="toggle-icon">
                            <i class="fas fa-chevron-down"></i>
                        </span>
                    </div>
                    <div class="faq-answer">
                        <div class="answer-content">
                            To prepare for your first consultation, please:
                            <ul>
                                <li>Bring your medical history and any previous test results</li>
                                <li>List all current medications and supplements</li>
                                <li>Note down any symptoms or concerns you want to discuss</li>
                                <li>Arrive 15 minutes early to complete necessary paperwork</li>
                                <li>Bring your insurance information and identification</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Treatment -->
                <div class="faq-item" data-category="treatment">
                    <div class="faq-question">
                        <h3 class="question-text">What treatment approaches do you use?</h3>
                        <span class="toggle-icon">
                            <i class="fas fa-chevron-down"></i>
                        </span>
                    </div>
                    <div class="faq-answer">
                        <div class="answer-content">
                            Our treatment approaches are evidence-based and may include:
                            <ul>
                                <li>Medication management</li>
                                <li>Lifestyle modifications</li>
                                <li>Physical therapy</li>
                                <li>Nutritional counseling</li>
                                <li>Preventive care strategies</li>
                            </ul>
                            All treatments are tailored to your specific condition and health goals.
                        </div>
                    </div>
                </div>

                <div class="faq-item" data-category="treatment">
                    <div class="faq-question">
                        <h3 class="question-text">How long does treatment typically last?</h3>
                        <span class="toggle-icon">
                            <i class="fas fa-chevron-down"></i>
                        </span>
                    </div>
                    <div class="faq-answer">
                        <div class="answer-content">
                            Treatment duration varies depending on your condition and response to therapy. Some acute conditions may require short-term treatment, while chronic conditions may need ongoing management. Your healthcare provider will discuss the expected treatment timeline during your consultation and adjust it based on your progress.
                        </div>
                    </div>
                </div>

                <!-- Safety -->
                <div class="faq-item" data-category="safety">
                    <div class="faq-question">
                        <h3 class="question-text">What safety measures do you have in place?</h3>
                        <span class="toggle-icon">
                            <i class="fas fa-chevron-down"></i>
                        </span>
                    </div>
                    <div class="faq-answer">
                        <div class="answer-content">
                            We maintain strict safety protocols including:
                            <ul>
                                <li>Regular facility sanitization</li>
                                <li>Personal protective equipment for staff</li>
                                <li>Patient screening procedures</li>
                                <li>Emergency response protocols</li>
                                <li>Infection control measures</li>
                            </ul>
                            Your safety and well-being are our top priorities.
                        </div>
                    </div>
                </div>

                <div class="faq-item" data-category="safety">
                    <div class="faq-question">
                        <h3 class="question-text">What should I do in case of a medical emergency?</h3>
                        <span class="toggle-icon">
                            <i class="fas fa-chevron-down"></i>
                        </span>
                    </div>
                    <div class="faq-answer">
                        <div class="answer-content">
                            In case of a medical emergency:
                            <ul>
                                <li>Call emergency services immediately (911)</li>
                                <li>Do not wait for a scheduled appointment</li>
                                <li>If possible, inform our office about the emergency</li>
                                <li>Follow the instructions of emergency responders</li>
                                <li>Keep your medical information accessible</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Consultation -->
                <div class="faq-item" data-category="consultation">
                    <div class="faq-question">
                        <h3 class="question-text">How do I schedule a consultation?</h3>
                        <span class="toggle-icon">
                            <i class="fas fa-chevron-down"></i>
                        </span>
                    </div>
                    <div class="faq-answer">
                        <div class="answer-content">
                            You can schedule a consultation by:
                            <ul>
                                <li>Calling our office during business hours</li>
                                <li>Using our online appointment system</li>
                                <li>Visiting our office in person</li>
                                <li>Requesting a callback through our website</li>
                            </ul>
                            New patients are typically seen within 24-48 hours of scheduling.
                        </div>
                    </div>
                </div>

                <div class="faq-item" data-category="consultation">
                    <div class="faq-question">
                        <h3 class="question-text">What should I expect during a consultation?</h3>
                        <span class="toggle-icon">
                            <i class="fas fa-chevron-down"></i>
                        </span>
                    </div>
                    <div class="faq-answer">
                        <div class="answer-content">
                            During your consultation, you can expect:
                            <ul>
                                <li>A thorough medical history review</li>
                                <li>Physical examination if needed</li>
                                <li>Discussion of your symptoms and concerns</li>
                                <li>Development of a treatment plan</li>
                                <li>Time for questions and answers</li>
                                <li>Follow-up instructions and next steps</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="contact-support text-center mt-5">
                <p class="mb-3">Can't find what you're looking for?</p>
                <a href="contact.php" class="btn btn-primary">
                    <i class="fas fa-envelope me-2"></i>
                    Contact Support
                </a>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // FAQ Accordion
        const faqItems = document.querySelectorAll('.faq-item');
        const categoryButtons = document.querySelectorAll('.category-btn');

        // Toggle FAQ items
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            question.addEventListener('click', () => {
                const isActive = item.classList.contains('active');
                
                // Close all items
                faqItems.forEach(i => i.classList.remove('active'));
                
                // Open clicked item if it wasn't active
                if (!isActive) {
                    item.classList.add('active');
                }
            });
        });

        // Category filtering
        categoryButtons.forEach(button => {
            button.addEventListener('click', function() {
                categoryButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');

                const category = this.dataset.category;

                faqItems.forEach(item => {
                    const itemCategory = item.dataset.category;
                    const matchesCategory = category === 'all' || itemCategory === category;
                    item.style.display = matchesCategory ? 'block' : 'none';
                });
            });
        });

        // Animate FAQ items on load
        faqItems.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(20px)';
            item.style.transition = 'all 0.3s ease';
            
            setTimeout(() => {
                item.style.opacity = '1';
                item.style.transform = 'translateY(0)';
            }, index * 100);
        });
    });
    </script>
</body>
</html> 