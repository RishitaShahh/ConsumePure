<?php
session_start();
include('smtp/PHPMailerAutoload.php');

$name = $email = $subject = $message = "";
$name_err = $email_err = $subject_err = $message_err = "";
$success_msg = $error_msg = "";

function smtp_mailer($to, $subject, $msg) {
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = ' consumepure@gmail.com '; // Your Gmail
    $mail->Password   = 'exif cnln cghj aieg'; // App Password
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;
    
    $mail->setFrom('$email', 'ConsumePure Contact Form');
    $mail->addAddress($to);
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $msg;
    
    if($mail->send()) {
        return true;
    } else {
        return false;
    }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    if(empty(trim($_POST["name"]))){
        $name_err = "Please enter your name.";
    } else{
        $name = trim($_POST["name"]);
    }
    
    // Validate email
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter your email.";
    } elseif(!filter_var(trim($_POST["email"]), FILTER_VALIDATE_EMAIL)){
        $email_err = "Please enter a valid email address.";
    } else{
        $email = trim($_POST["email"]);
    }
    
    // Validate subject
    if(empty(trim($_POST["subject"]))){
        $subject_err = "Please enter a subject.";
    } else{
        $subject = trim($_POST["subject"]);
    }
    
    // Validate message
    if(empty(trim($_POST["message"]))){
        $message_err = "Please enter your message.";
    } else{
        $message = trim($_POST["message"]);
    }
    
    // If no errors, send email
    if(empty($name_err) && empty($email_err) && empty($subject_err) && empty($message_err)){
        $to = "consumepure@gmail.com";
        $subject = "New Contact Form Submission: " . $subject;
        $msg = "
            <h2>New Contact Form Submission</h2>
            <p><strong>Name:</strong> {$name}</p>
            <p><strong>Email:</strong> {$email}</p>
            <p><strong>Subject:</strong> {$subject}</p>
            <p><strong>Message:</strong></p>
            <p>{$message}</p>
        ";
        
        if(smtp_mailer($to, $subject, $msg)){
            $success_msg = "Your message has been sent successfully!";
            // Clear form
            $name = $email = $subject = $message = "";
        } else {
            $error_msg = "Message could not be sent. Please try again later.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - ConsumePure</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .contact-container {
            padding: 40px 0;
            max-width: 1140px;
            margin: 0 auto;
        }
        .contact-title {
            color: #0d6efd;
            font-size: 2rem;
            text-align: center;
            margin-bottom: 1rem;
        }
        .contact-subtitle {
            text-align: center;
            color: #6c757d;
            margin-bottom: 2.5rem;
            font-size: 1rem;
        }
        .contact-form {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
        }
        .contact-info-section {
            padding-left: 40px;
        }
        .contact-info-title {
            color: #0d6efd;
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
        }
        .info-item {
            margin-bottom: 1.5rem;
        }
        .info-item strong {
            display: block;
            margin-bottom: 0.5rem;
            color: #333;
        }
        .info-item p {
            margin: 0;
            color: #666;
            line-height: 1.6;
        }
        .info-item a {
            color: #0d6efd;
            text-decoration: none;
        }
        .info-item a:hover {
            text-decoration: underline;
        }
        .business-hours {
            margin-top: 2rem;
        }
        .hours-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .hours-list li {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid #eee;
        }
        .hours-list li:last-child {
            border-bottom: none;
        }
        .form-control {
            border: 1px solid #ced4da;
            padding: 0.5rem;
        }
        .form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
        }
        .btn-send {
            background: #0d6efd;
            color: white;
            padding: 0.75rem 2rem;
            border: none;
            border-radius: 4px;
            width: 100%;
            font-weight: 500;
        }
        .btn-send:hover {
            background: #0b5ed7;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="contact-container">
        <h1 class="contact-title">Contact Us</h1>
        <p class="contact-subtitle">Have questions or concerns? We're here to help. Fill out the form below and we'll get back to you as soon as possible.</p>
        
        <div class="row">
            <div class="col-md-6">
                <div class="contact-form">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control <?php echo (!empty($name_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $name; ?>">
                            <span class="invalid-feedback"><?php echo $name_err; ?></span>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                            <span class="invalid-feedback"><?php echo $email_err; ?></span>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Subject</label>
                            <input type="text" name="subject" class="form-control <?php echo (!empty($subject_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $subject; ?>">
                            <span class="invalid-feedback"><?php echo $subject_err; ?></span>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label">Message</label>
                            <textarea name="message" class="form-control <?php echo (!empty($message_err)) ? 'is-invalid' : ''; ?>" rows="4"><?php echo $message; ?></textarea>
                            <span class="invalid-feedback"><?php echo $message_err; ?></span>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn-send">Send Message</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="contact-info-section">
                    <h3 class="contact-info-title">Contact Information</h3>
                    
                    <div class="info-item">
                        <strong>Address:</strong>
                        <p>Smriti Nagar<br>
                        Airport Road<br>
                        Indore, Madhya Pradesh</p>
                    </div>
                    
                    <div class="info-item">
                        <strong>Email:</strong>
                        <p><a href="mailto:consumepure@gmail.com">consumepure@gmail.com</a></p>
                    </div>
                    
                    <div class="info-item">
                        <strong>Phone:</strong>
                        <p><a href="tel:+917974928294">+91 7974928294</a></p>
                    </div>
                    
                    <div class="business-hours">
                        <h3 class="contact-info-title">Business Hours</h3>
                        <ul class="hours-list">
                            <li>
                                <span>Monday - Friday:</span>
                                <span>9:00 AM - 6:00 PM</span>
                            </li>
                            <li>
                                <span>Saturday:</span>
                                <span>10:00 AM - 4:00 PM</span>
                            </li>
                            <li>
                                <span>Sunday:</span>
                                <span>Closed</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script>
        <?php if(!empty($success_msg)): ?>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '<?php echo $success_msg; ?>',
                confirmButtonColor: '#007bff'
            });
        <?php endif; ?>

        <?php if(!empty($error_msg)): ?>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: '<?php echo $error_msg; ?>',
                confirmButtonColor: '#dc3545'
            });
        <?php endif; ?>
    </script>
</body>
</html> 