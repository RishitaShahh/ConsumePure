<?php
session_start();
include('smtp/PHPMailerAutoload.php');

function send_confirmation_email($to_email, $user_name) {
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'consumepure@gmail.com'; // Your Gmail
    $mail->Password   = 'exif cnln cghj aieg'; // Your provided App Password
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;
    
    $mail->setFrom('consumepure@gmail.com', 'ConsumePure');
    $mail->addAddress($to_email);
    $mail->isHTML(true);
    
    $mail->Subject = 'Welcome to ConsumePure - Registration Confirmation';
    
    // Email body with HTML formatting
    $mail->Body = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
            <h2 style='color: #0d6efd;'>Welcome to ConsumePure!</h2>
            <p>Dear {$user_name},</p>
            
            <p>Thank you for registering with ConsumePure! We're excited to have you as a part of our community.</p>
            
            <p>Your registration has been successfully completed. You can now access all our services and features using your registered email address.</p>
            
            <h3>What's Next?</h3>
            <ul>
                <li>Explore our wide range of pure and natural products</li>
                <li>Update your profile information</li>
                <li>Browse through our latest offers and deals</li>
            </ul>
            
            <p>If you have any questions or need assistance, please don't hesitate to contact our support team at contact@consumepure.com</p>
            
            <p style='margin-top: 20px;'>Best regards,<br>The ConsumePure Team</p>
            
            <div style='margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #666;'>
                <p>This is an automated message, please do not reply to this email.</p>
            </div>
        </div>
    ";
    
    // Plain text version for non-HTML mail clients
    $mail->AltBody = "
        Welcome to ConsumePure!
        
        Dear {$user_name},
        
        Thank you for registering with ConsumePure! We're excited to have you as a part of our community.
        
        Your registration has been successfully completed. You can now access all our services and features using your registered email address.
        
        If you have any questions or need assistance, please contact our support team at contact@consumepure.com
        
        Best regards,
        The ConsumePure Team
    ";
    
    if($mail->send()) {
        return true;
    } else {
        return false;
    }
}

// Check if the user is already logged in
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: index.php");
    exit;
}

// Include database connection
require_once "config/database.php";

$username = $password = $confirm_password = $email = "";
$username_err = $password_err = $confirm_password_err = $email_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate reCAPTCHA
    if(isset($_POST['g-recaptcha-response'])){
        $recaptcha_response = $_POST['g-recaptcha-response'];
        $secret_key = "6LczeCIrAAAAAL41J-TRVseYf9nGM4hLO32wHdFs";
        $verify_response = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret_key.'&response='.$recaptcha_response);
        $response_data = json_decode($verify_response);
        
        if(!$response_data->success){
            $recaptcha_err = "Please complete the reCAPTCHA verification.";
        }
    } else {
        $recaptcha_err = "Please complete the reCAPTCHA verification.";
    }

    // Validate email
    if(!isset($_POST["email"]) || empty(trim($_POST["email"]))){
        $email_err = "Please enter an email.";
    } elseif(!filter_var(trim($_POST["email"]), FILTER_VALIDATE_EMAIL)){
        $email_err = "Please enter a valid email address.";
    } else{
        $sql = "SELECT id FROM users WHERE email = ?";
        
        if($stmt = mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "s", $param_email);
            $param_email = trim($_POST["email"]);
            
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $email_err = "This email is already registered.";
                } else{
                    $email = trim($_POST["email"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))){
        $username_err = "Username can only contain letters, numbers, and underscores.";
    } else{
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            $param_username = trim($_POST["username"]);
            
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have at least 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($email_err) && empty($recaptcha_err)){
        $sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
         
        if($stmt = mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "sss", $param_username, $param_password, $param_email);
            
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT);
            $param_email = $email;
            
            if(mysqli_stmt_execute($stmt)){
                // Send confirmation email
                if(send_confirmation_email($email, $username)) {
                    $_SESSION['success_msg'] = "Registration successful! A confirmation email has been sent to your email address.";
                } else {
                    $_SESSION['error_msg'] = "Registration successful but failed to send confirmation email. Please check your email address.";
                }
                header("location: login.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            mysqli_stmt_close($stmt);
        }
    }
    
    mysqli_close($conn);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account - ConsumePure</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        :root {
            --primary-blue: #007bff;
            --light-blue: #f8f9fa;
        }
        body {
            background-color: var(--light-blue);
        }
        .wrapper{ 
            width: 400px; 
            padding: 30px;
            margin: 0 auto;
            margin-top: 50px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary-blue);
            font-size: 2em;
            font-weight: bold;
        }
        .btn-primary {
            background-color: var(--primary-blue);
            border-color: var(--primary-blue);
        }
        .form-control:focus {
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="logo">ConsumePure</div>
        <h2 class="text-center mb-4">Create Account</h2>
        <p class="text-center text-muted mb-4">Join our community of health-conscious individuals</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                <span class="invalid-feedback"><?php echo $email_err; ?></span>
            </div>    
            <div class="form-group mb-3">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>
            <div class="form-group mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group mb-4">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="form-group mb-4">
                <div class="g-recaptcha" data-sitekey="6LczeCIrAAAAAOZmVAYOxRMz-rtvWeXv3HQFThd8"></div>
                <?php if(!empty($recaptcha_err)): ?>
                    <span class="text-danger"><?php echo $recaptcha_err; ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group mb-4">
                <input type="submit" class="btn btn-primary w-100" value="Create Account">
            </div>
            <p class="text-center">Already have an account? <a href="login.php">Login here</a></p>
        </form>
    </div>    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if(!empty($success_msg)): ?>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '<?php echo $success_msg; ?>',
                confirmButtonColor: '#007bff'
            });
        <?php endif; ?>

        <?php if(!empty($error_msg)): ?>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: '<?php echo $error_msg; ?>',
                confirmButtonColor: '#dc3545'
            });
        <?php endif; ?>
    </script>
</body>
</html>