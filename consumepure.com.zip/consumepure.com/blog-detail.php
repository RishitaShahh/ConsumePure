<?php
require_once "config/database.php";
session_start();

// Get the post ID from the URL
$post_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get blog posts (same array as in blog.php)
$blog_posts = array(
    array(
        'title' => 'When Not to Take Antibiotics',
        'excerpt' => 'Antibiotics are powerful medicines, but they\'re not the solution for all illnesses. Learn when to avoid them.',
        'content' => '<p>Antibiotics are essential medicines that have saved countless lives. However, their misuse and overuse have led to the development of antibiotic resistance, a serious global health concern.</p>
                     <p>Here are situations when you should avoid taking antibiotics:</p>
                     <ul>
                         <li>For viral infections like colds and flu</li>
                         <li>For mild bacterial infections that your body can fight naturally</li>
                         <li>Without a proper prescription from a healthcare provider</li>
                     </ul>',
        'author' => 'Dr. Sarah Johnson',
        'date' => '2024-03-15',
        'image' => 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&auto=format&fit=crop&q=60',
        'category' => 'Medicine Safety'
    ),
    array(
        'title' => 'How to Store Medicines Safely',
        'excerpt' => 'Proper medicine storage is crucial for maintaining their effectiveness and safety. Follow these essential guidelines.',
        'content' => '<p>Proper storage of medicines is essential to maintain their effectiveness and ensure your safety. Here are key guidelines to follow:</p>
                     <ul>
                         <li>Store medicines in a cool, dry place away from direct sunlight</li>
                         <li>Keep medicines out of reach of children and pets</li>
                         <li>Check expiration dates regularly</li>
                         <li>Store medicines in their original containers</li>
                     </ul>',
        'author' => 'Dr. Michael Chen',
        'date' => '2024-03-10',
        'image' => 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&auto=format&fit=crop&q=60',
        'category' => 'Medicine Safety'
    ),
    array(
        'title' => 'Understanding Medicine Labels',
        'excerpt' => 'Medicine labels contain vital information. Learn how to read and understand them properly.',
        'content' => '<p>Medicine labels contain crucial information about your medication. Understanding them is essential for safe and effective use.</p>
                     <p>Key elements to look for on medicine labels:</p>
                     <ul>
                         <li>Active ingredients and their amounts</li>
                         <li>Usage instructions and dosage</li>
                         <li>Expiration date</li>
                         <li>Storage requirements</li>
                         <li>Potential side effects and warnings</li>
                     </ul>',
        'author' => 'Dr. Emily Wilson',
        'date' => '2024-03-05',
        'image' => 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=60',
        'category' => 'Medicine Education'
    ),
    array(
        'title' => 'Common Drug Interactions to Avoid',
        'excerpt' => 'Some medications don\'t mix well together. Learn about common interactions and how to avoid them.',
        'content' => '<p>Drug interactions can occur when two or more medications affect each other\'s actions in the body. Some interactions can be dangerous.</p>
                     <p>Common types of drug interactions to be aware of:</p>
                     <ul>
                         <li>Drug-drug interactions</li>
                         <li>Drug-food interactions</li>
                         <li>Drug-alcohol interactions</li>
                         <li>Drug-supplement interactions</li>
                     </ul>',
        'author' => 'Dr. James Martinez',
        'date' => '2024-03-01',
        'image' => 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&auto=format&fit=crop&q=60',
        'category' => 'Medicine Safety'
    )
);

// Get the current post
$current_post = isset($blog_posts[$post_id]) ? $blog_posts[$post_id] : null;

if (!$current_post) {
    header("Location: blog.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Detail - ConsumePure</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #1a73e8;
            --light-blue: #e8f0fe;
            --dark-blue: #1557b0;
            --text-color: #333;
            --light-text: #666;
            --border-color: #e0e0e0;
        }

        .blog-detail-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 2rem;
        }

        .blog-detail-header {
            text-align: center;
            margin-bottom: 3rem;
            position: relative;
        }

        .blog-detail-header h1 {
            color: var(--primary-blue);
            font-size: 2.8rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            line-height: 1.3;
        }

        .blog-detail-meta {
            display: flex;
            justify-content: center;
            gap: 2rem;
            color: var(--light-text);
            margin-bottom: 2rem;
        }

        .blog-detail-meta span {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .blog-detail-meta i {
            color: var(--primary-blue);
        }

        .blog-detail-image {
            width: 100%;
            max-width: 800px;
            height: auto;
            border-radius: 16px;
            margin: 2rem auto;
            display: block;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .blog-detail-image img {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.5s ease;
        }

        .blog-detail-image:hover img {
            transform: scale(1.05);
        }

        .blog-detail-image:after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .blog-detail-image:hover:after {
            opacity: 1;
        }

        .blog-detail-content {
            font-size: 1.1rem;
            line-height: 1.8;
            color: var(--text-color);
        }

        .blog-detail-content p {
            margin-bottom: 1.5rem;
        }

        .blog-detail-content h2,
        .blog-detail-content h3 {
            color: var(--primary-blue);
            margin: 2.5rem 0 1.5rem;
            font-weight: 600;
        }

        .blog-detail-content ul,
        .blog-detail-content ol {
            margin-bottom: 1.5rem;
            padding-left: 2rem;
        }

        .blog-detail-content li {
            margin-bottom: 0.8rem;
        }

        .btn-primary {
            display: inline-flex;
            align-items: center;
            padding: 1.1rem 2.4rem;
            background: linear-gradient(135deg, var(--primary-blue) 0%, var(--dark-blue) 100%);
            color: white;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            margin: 3rem auto;
            border: none;
            position: relative;
            overflow: hidden;
            z-index: 1;
            box-shadow: 0 4px 15px rgba(26, 115, 232, 0.2);
            letter-spacing: 0.5px;
            text-transform: uppercase;
            cursor: pointer;
        }

        .btn-primary:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--dark-blue) 0%, var(--primary-blue) 100%);
            z-index: -1;
            opacity: 0;
            transition: opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .btn-primary:hover {
            color: white;
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 8px 25px rgba(26, 115, 232, 0.3);
        }

        .btn-primary:hover:before {
            opacity: 1;
        }

        .btn-primary i {
            margin-right: 0.8rem;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            font-size: 1.2rem;
            transform: translateX(0);
        }

        .btn-primary:hover i {
            transform: translateX(-5px) rotate(-10deg);
        }

        .btn-primary:active {
            transform: translateY(-1px) scale(0.98);
            box-shadow: 0 4px 15px rgba(26, 115, 232, 0.2);
        }

        @media (max-width: 768px) {
            .blog-detail-container {
                padding: 1rem;
            }

            .blog-detail-header h1 {
                font-size: 2rem;
            }

            .blog-detail-meta {
                flex-direction: column;
                gap: 1rem;
                align-items: center;
            }

            .blog-detail-image {
                margin: 1.5rem auto;
                border-radius: 12px;
            }

            .btn-primary {
                padding: 1rem 2rem;
                font-size: 1rem;
            }
        }

        /* Animation Classes */
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }

        .slide-up {
            animation: slideUp 0.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { 
                opacity: 0;
                transform: translateY(20px);
            }
            to { 
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <main class="container" style="padding: 4rem 0;">
        <article class="blog-post">
            <div class="post-header" style="text-align: center; margin-bottom: 2rem;">
                <span class="category" style="background-color: var(--light-blue); color: var(--primary-blue); 
                                            padding: 0.25rem 0.75rem; border-radius: 1rem; font-size: 0.875rem;">
                    <?php echo htmlspecialchars($current_post['category']); ?>
                </span>
                <h1 style="margin: 1rem 0; font-size: 2.5rem;">
                    <?php echo htmlspecialchars($current_post['title']); ?>
                </h1>
                <div style="display: flex; justify-content: center; gap: 1rem; color: #666;">
                    <span>By <?php echo htmlspecialchars($current_post['author']); ?></span>
                    <span>•</span>
                    <span><?php echo date('F j, Y', strtotime($current_post['date'])); ?></span>
                </div>
            </div>

            <div class="post-image" style="margin-bottom: 2rem;">
                <img src="<?php echo htmlspecialchars($current_post['image']); ?>" 
                     alt="<?php echo htmlspecialchars($current_post['title']); ?>"
                     style="width: 100%; border-radius: 8px;">
            </div>

            <div class="post-content" style="max-width: 800px; margin: 0 auto; line-height: 1.6;">
                <?php echo $current_post['content']; ?>
            </div>

            <div style="text-align: center; margin-top: 3rem;">
                <a href="blog.php" class="btn-primary">Back to Blog</a>
            </div>
        </article>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html> 