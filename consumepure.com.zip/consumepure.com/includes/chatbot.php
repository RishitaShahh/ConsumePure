<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['chat_session_id'])) {
    $_SESSION['chat_session_id'] = uniqid();
}
?>
<div id="chatbot-container" class="chatbot-container">
    <div id="chatbot-toggle" class="chatbot-toggle">
        <i class="fas fa-user-graduate"></i>
    </div>
    <div id="chatbot-window" class="chatbot-window">
        <div class="chatbot-header">
                    <h3>Medical Assistant</h3>
            <div class="chatbot-controls">
                <button id="voice-toggle" class="voice-toggle">
                    <i class="fas fa-microphone"></i>
                </button>
                <button id="close-chatbot" class="close-chatbot">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
        <div id="chat-messages" class="chat-messages">
            <div class="bot-message">
                <p>Hi there! How can I assist you with your health today?</p>
            </div>
        </div>
        <div class="chat-input">
            <textarea id="user-input" placeholder="Type your message here..."></textarea>
            <button id="send-message">
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>
    </div>
</div>

<style>
.chatbot-container {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 1000;
}

.chatbot-toggle {
    background: var(--primary-color);
    color: white;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.chatbot-toggle:hover {
    transform: scale(1.1);
}

.chatbot-window {
    position: absolute;
    bottom: 80px;
    right: 0;
    width: 350px;
    height: 500px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    display: none;
    flex-direction: column;
}

.chatbot-window.active {
    display: flex;
}

.chatbot-header {
    padding: 15px;
    background: var(--primary-color);
    color: white;
    border-radius: 10px 10px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.chatbot-controls button {
    background: none;
    border: none;
    color: white;
    cursor: pointer;
    padding: 5px;
    margin-left: 10px;
}

.chat-messages {
    flex: 1;
    padding: 15px;
    overflow-y: auto;
}

.bot-message, .user-message {
    margin-bottom: 15px;
    padding: 10px;
    border-radius: 10px;
    max-width: 80%;
}

.bot-message {
    background: #f0f0f0;
    margin-right: auto;
}

.user-message {
    background: var(--primary-color);
    color: white;
    margin-left: auto;
}

.chat-input {
    padding: 15px;
    border-top: 1px solid #eee;
    display: flex;
    gap: 10px;
}

.chat-input textarea {
    flex: 1;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    resize: none;
    height: 40px;
}

.chat-input button {
    background: var(--primary-color);
    color: white;
    border: none;
    border-radius: 5px;
    padding: 0 15px;
    cursor: pointer;
}

.voice-toggle.active {
    color: #ff4444;
    animation: pulse 1.5s infinite;
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.2); }
    100% { transform: scale(1); }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const chatbotToggle = document.getElementById('chatbot-toggle');
    const chatbotWindow = document.getElementById('chatbot-window');
    const closeChatbot = document.getElementById('close-chatbot');
    const voiceToggle = document.getElementById('voice-toggle');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-message');
    const chatMessages = document.getElementById('chat-messages');
    let recognition = null;

    // Initialize Web Speech API
    if ('webkitSpeechRecognition' in window) {
        recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            userInput.value = transcript;
            sendMessage();
        };

        recognition.onerror = function(event) {
            console.error('Speech recognition error', event.error);
        };
    }

    chatbotToggle.addEventListener('click', () => {
        chatbotWindow.classList.add('active');
    });

    closeChatbot.addEventListener('click', () => {
        chatbotWindow.classList.remove('active');
        if (recognition) {
            recognition.stop();
            voiceToggle.classList.remove('active');
        }
    });

    voiceToggle.addEventListener('click', () => {
        if (!recognition) {
            alert('Speech recognition is not supported in your browser.');
            return;
        }

        if (voiceToggle.classList.contains('active')) {
            recognition.stop();
            voiceToggle.classList.remove('active');
        } else {
            recognition.start();
            voiceToggle.classList.add('active');
        }
    });

    function sendMessage() {
        const message = userInput.value.trim();
        if (!message) return;

        // Add user message to chat
        addMessage(message, 'user');
        userInput.value = '';

        // Send message to server
        fetch('chatbot/process.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message,
                session_id: '<?php echo $_SESSION['chat_session_id']; ?>'
            })
        })
        .then(response => response.json())
        .then(data => {
            addMessage(data.response, 'bot');
        })
        .catch(error => {
            console.error('Error:', error);
            addMessage('Sorry, I encountered an error. Please try again.', 'bot');
        });
    }

    function addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `${sender}-message`;
        messageDiv.innerHTML = `<p>${text}</p>`;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
});
</script> 