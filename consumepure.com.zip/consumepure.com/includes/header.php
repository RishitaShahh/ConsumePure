<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ConsumePure - Your Health Partner</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #1a73e8;
            --secondary-color: #1557b0;
            --text-color: #2c3e50;
            --light-text: #6c757d;
            --light-bg: #f8f9fa;
            --border-color: #e9ecef;
        }

        .top-bar {
            background: var(--light-bg);
            padding: 0.5rem 0;
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }

        .contact-info {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 1.5rem;
        }

        .contact-info a {
            color: var(--text-color);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s ease;
            padding: 0.3rem 0.6rem;
            border-radius: 4px;
        }

        .contact-info a:hover {
            background: var(--border-color);
            color: var(--primary-color);
        }

        .contact-info i {
            color: var(--primary-color);
            font-size: 0.9rem;
            transition: transform 0.2s ease;
        }

        .contact-info a:hover i {
            transform: scale(1.1);
        }

        .navbar {
            padding: 1rem 0;
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            text-decoration: none;
            color: var(--text-color);
        }

        .logo-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: var(--primary-color);
            border-radius: 8px;
            color: white;
            font-size: 1.5rem;
            transition: all 0.3s ease;
        }

        .logo-text {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--text-color);
            transition: color 0.3s ease;
        }

        .logo:hover .logo-icon {
            transform: scale(1.05);
            background: var(--secondary-color);
        }

        .logo:hover .logo-text {
            color: var(--primary-color);
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .nav-menu li a {
            color: var(--text-color);
            text-decoration: none;
            font-weight: 500;
            font-size: 0.95rem;
            padding: 0.5rem 0;
            position: relative;
            transition: all 0.2s ease;
        }

        .nav-menu li a:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.3s ease;
        }

        .nav-menu li a:hover {
            color: var(--primary-color);
        }

        .nav-menu li a:hover:after {
            width: 100%;
        }

        .nav-menu li.active a {
            color: var(--primary-color);
        }

        .nav-menu li.active a:after {
            width: 100%;
        }

        @media (max-width: 992px) {
            .nav-menu {
                gap: 1rem;
            }

            .nav-menu li a {
                font-size: 0.9rem;
            }
        }

        @media (max-width: 768px) {
            .contact-info {
                justify-content: center;
                flex-wrap: wrap;
                gap: 1rem;
            }

            .contact-info a {
                font-size: 0.85rem;
                padding: 0.2rem 0.4rem;
            }

            .navbar {
                padding: 0.8rem 0;
            }

            .logo img {
                height: 35px;
            }

            .nav-menu {
                display: none;
            }

            .nav-menu.active {
                display: flex;
                flex-direction: column;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: white;
                padding: 1rem;
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                z-index: 1000;
            }

            .nav-menu li {
                width: 100%;
                text-align: center;
                padding: 0.5rem 0;
            }

            .nav-menu li a {
                display: block;
                padding: 0.5rem 0;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="top-bar">
            <div class="container">
                <div class="contact-info">
                    <a href="tel:+917974928294">
                        <i class="fas fa-phone-alt"></i>
                        +91 7974928294
                    </a>
                    <a href="mailto:consumepure@gmail.com">
                        <i class="fas fa-envelope"></i>
                        consumepure@gmail.com
                    </a>
                </div>
            </div>
        </div>
        <nav class="navbar container">
            <div class="logo">
                <a href="index.php" class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-pills"></i>
                    </div>
                    <span class="logo-text">ConsumePure</span>
                </a>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="blog.php">Health Tips</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact</a></li>
                <?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true): ?>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    <main class="container">
    <script src="assets/js/main.js"></script>
    <?php include 'chatbot.php'; ?>
</body>
</html> 