<?php
require_once "config/database.php";
session_start();

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Get all medicines
$medicines = array();
$sql = "SELECT * FROM medicines ORDER BY name ASC";
if($result = mysqli_query($conn, $sql)){
    while($row = mysqli_fetch_array($result)){
        $medicines[] = $row;
    }
    mysqli_free_result($result);
}
?>

<?php include 'includes/header.php'; ?>

<main class="medicines-container">
    <div class="medicines-section">
        <div class="medicines-header text-center mb-5">
            <h1 class="display-4 fw-bold text-primary">Our Medicines</h1>
            <p class="lead text-muted">Browse our comprehensive collection of medicines</p>
        </div>

        <div class="filters-section mb-4">
            <div class="row g-3">
                <div class="col-md-4">
                    <div class="search-box">
                        <input type="text" id="searchInput" class="form-control" placeholder="Search medicines...">
                        <i class="fas fa-search search-icon"></i>
                    </div>
                </div>
                <div class="col-md-4">
                    <select class="form-select" id="categoryFilter">
                        <option value="">All Categories</option>
                        <?php foreach($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <select class="form-select" id="sortFilter">
                        <option value="name_asc">Sort by Name (A-Z)</option>
                        <option value="name_desc">Sort by Name (Z-A)</option>
                        <option value="price_asc">Price: Low to High</option>
                        <option value="price_desc">Price: High to Low</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="medicines-grid">
            <?php foreach($medicines as $medicine): ?>
                <div class="medicine-card" data-category="<?php echo $medicine['category_id']; ?>">
                    <div class="card-image">
                        <img src="<?php echo $medicine['image_url']; ?>" alt="<?php echo $medicine['name']; ?>">
                        <?php if($medicine['is_new']): ?>
                            <span class="badge new-badge">New</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <h3 class="medicine-name"><?php echo $medicine['name']; ?></h3>
                        <p class="medicine-description"><?php echo substr($medicine['description'], 0, 100) . '...'; ?></p>
                        <div class="medicine-details">
                            <span class="price">$<?php echo number_format($medicine['price'], 2); ?></span>
                            <span class="category"><?php echo $medicine['category_name']; ?></span>
                        </div>
                        <div class="card-actions">
                            <a href="medicine-details.php?id=<?php echo $medicine['id']; ?>" class="view-btn">
                                View Details
                                <i class="fas fa-arrow-right"></i>
                            </a>
                            <button class="add-to-cart-btn" data-id="<?php echo $medicine['id']; ?>">
                                <i class="fas fa-shopping-cart"></i>
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="pagination-container">
            <?php if($total_pages > 1): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <?php if($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo ($page-1); ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php for($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                        
                        <?php if($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo ($page+1); ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</main>

<style>
    .medicines-container {
        padding: 4rem 0;
        background: #f8f9fa;
        min-height: calc(100vh - 60px);
    }

    .medicines-section {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 1rem;
    }

    .medicines-header {
        margin-bottom: 3rem;
    }

    .filters-section {
        background: white;
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        margin-bottom: 2rem;
    }

    .search-box {
        position: relative;
    }

    .search-box input {
        padding-left: 2.5rem;
        border-radius: 10px;
        border: 1px solid #e9ecef;
    }

    .search-icon {
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: #6c757d;
    }

    .form-select {
        border-radius: 10px;
        border: 1px solid #e9ecef;
    }

    .medicines-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 2rem;
        margin-bottom: 3rem;
    }

    .medicine-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .medicine-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .card-image {
        position: relative;
        height: 200px;
        overflow: hidden;
    }

    .card-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .medicine-card:hover .card-image img {
        transform: scale(1.05);
    }

    .new-badge {
        position: absolute;
        top: 1rem;
        right: 1rem;
        background: #4a90e2;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
    }

    .card-content {
        padding: 1.5rem;
    }

    .medicine-name {
        font-size: 1.25rem;
        font-weight: 600;
        margin-bottom: 0.5rem;
        color: #2c3e50;
    }

    .medicine-description {
        color: #6c757d;
        margin-bottom: 1rem;
        line-height: 1.5;
    }

    .medicine-details {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }

    .price {
        font-size: 1.25rem;
        font-weight: 600;
        color: #4a90e2;
    }

    .category {
        background: #e9ecef;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.875rem;
        color: #6c757d;
    }

    .card-actions {
        display: flex;
        gap: 1rem;
    }

    .view-btn, .add-to-cart-btn {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0.75rem;
        border-radius: 10px;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .view-btn {
        background: #4a90e2;
        color: white;
        text-decoration: none;
    }

    .view-btn:hover {
        background: #357abd;
        color: white;
    }

    .add-to-cart-btn {
        background: #f8f9fa;
        color: #2c3e50;
        border: 1px solid #e9ecef;
    }

    .add-to-cart-btn:hover {
        background: #e9ecef;
    }

    .pagination-container {
        margin-top: 2rem;
    }

    .page-link {
        color: #4a90e2;
        border: none;
        padding: 0.5rem 1rem;
        margin: 0 0.25rem;
        border-radius: 10px;
    }

    .page-item.active .page-link {
        background: #4a90e2;
        color: white;
    }

    .page-link:hover {
        background: #e9ecef;
        color: #4a90e2;
    }

    @media (max-width: 768px) {
        .medicines-container {
            padding: 2rem 0;
        }

        .medicines-grid {
            grid-template-columns: 1fr;
        }

        .card-actions {
            flex-direction: column;
        }

        .filters-section .row {
            flex-direction: column;
        }

        .filters-section .col-md-4 {
            margin-bottom: 1rem;
        }
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    const sortFilter = document.getElementById('sortFilter');
    const medicineCards = document.querySelectorAll('.medicine-card');

    function filterMedicines() {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedCategory = categoryFilter.value;
        const sortValue = sortFilter.value;

        medicineCards.forEach(card => {
            const name = card.querySelector('.medicine-name').textContent.toLowerCase();
            const category = card.dataset.category;
            const matchesSearch = name.includes(searchTerm);
            const matchesCategory = !selectedCategory || category === selectedCategory;

            if (matchesSearch && matchesCategory) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });

        // Sort functionality
        const visibleCards = Array.from(medicineCards).filter(card => card.style.display !== 'none');
        const grid = document.querySelector('.medicines-grid');
        
        visibleCards.sort((a, b) => {
            const nameA = a.querySelector('.medicine-name').textContent;
            const nameB = b.querySelector('.medicine-name').textContent;
            const priceA = parseFloat(a.querySelector('.price').textContent.replace('$', ''));
            const priceB = parseFloat(b.querySelector('.price').textContent.replace('$', ''));

            switch(sortValue) {
                case 'name_asc':
                    return nameA.localeCompare(nameB);
                case 'name_desc':
                    return nameB.localeCompare(nameA);
                case 'price_asc':
                    return priceA - priceB;
                case 'price_desc':
                    return priceB - priceA;
                default:
                    return 0;
            }
        });

        visibleCards.forEach(card => grid.appendChild(card));
    }

    searchInput.addEventListener('input', filterMedicines);
    categoryFilter.addEventListener('change', filterMedicines);
    sortFilter.addEventListener('change', filterMedicines);

    // Add to cart animation
    const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            this.innerHTML = '<i class="fas fa-check"></i> Added';
            this.style.background = '#28a745';
            this.style.color = 'white';
            
            setTimeout(() => {
                this.innerHTML = '<i class="fas fa-shopping-cart"></i> Add to Cart';
                this.style.background = '#f8f9fa';
                this.style.color = '#2c3e50';
            }, 2000);
        });
    });

    // Animate cards on load
    medicineCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.3s ease';
        
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
});
</script>

<?php include 'includes/footer.php'; ?> 