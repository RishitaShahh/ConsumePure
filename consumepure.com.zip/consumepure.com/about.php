<?php
require_once "config/database.php";
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - ConsumePure</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #1a73e8;
            --light-blue: #e8f0fe;
            --dark-blue: #1557b0;
            --text-color: #333;
            --light-text: #666;
            --border-color: #e0e0e0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
        }

        .about-header {
            text-align: center;
            margin-bottom: 5rem;
            position: relative;
            padding: 2rem 0;
        }

        .about-header h1 {
            color: var(--primary-blue);
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            position: relative;
            display: inline-block;
        }

        .about-header h1:after {
            content: '';
            position: absolute;
            width: 80px;
            height: 4px;
            background: var(--primary-blue);
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            border-radius: 2px;
        }

        .about-header p {
            max-width: 800px;
            margin: 1.5rem auto;
            font-size: 1.2rem;
            color: var(--light-text);
        }

        .about-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            margin-bottom: 5rem;
            align-items: center;
        }

        .about-content {
            padding: 2rem;
        }

        .about-content h2 {
            color: var(--primary-blue);
            font-size: 2.2rem;
            margin-bottom: 1.5rem;
            font-weight: 600;
        }

        .about-content p {
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
            color: var(--light-text);
            line-height: 1.8;
        }

        .about-image {
            position: relative;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .about-image:hover {
            transform: translateY(-5px);
        }

        .about-image img {
            width: 100%;
            height: auto;
            display: block;
            border-radius: 12px;
        }

        .values-section {
            margin-bottom: 5rem;
            padding: 4rem 0;
            background: var(--light-blue);
            border-radius: 20px;
        }

        .values-section h2 {
            text-align: center;
            color: var(--primary-blue);
            font-size: 2.2rem;
            margin-bottom: 3rem;
            font-weight: 600;
        }

        .value-card {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            height: 100%;
            border: 1px solid rgba(26, 115, 232, 0.1);
        }

        .value-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(26, 115, 232, 0.15);
            border-color: rgba(26, 115, 232, 0.3);
        }

        .value-card h3 {
            color: var(--primary-blue);
            font-size: 1.5rem;
            margin-bottom: 1rem;
            font-weight: 600;
        }

        .value-card p {
            color: var(--light-text);
            line-height: 1.8;
        }

        .team-section {
            margin-bottom: 5rem;
        }

        .team-section h2 {
            text-align: center;
            color: var(--primary-blue);
            font-size: 2.2rem;
            margin-bottom: 3rem;
            font-weight: 600;
        }

        .team-card {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            text-align: center;
            border: 1px solid rgba(26, 115, 232, 0.1);
        }

        .team-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(26, 115, 232, 0.15);
            border-color: rgba(26, 115, 232, 0.3);
        }

        .team-image {
            width: 180px;
            height: 180px;
            border-radius: 50%;
            overflow: hidden;
            margin: 0 auto 1.5rem;
            border: 4px solid white;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .team-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .team-card:hover .team-image img {
            transform: scale(1.05);
        }

        .team-card h3 {
            color: var(--text-color);
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }

        .team-card p {
            color: var(--primary-blue);
            font-weight: 500;
            margin-bottom: 1rem;
        }

        .social-links {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-top: 1.5rem;
        }

        .social-links a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: white;
            color: white;
            text-decoration: none;
            font-size: 1.2rem;
        }

        .social-links a:hover {
            background: white !important;
        }

        .social-links i {
            font-size: 1.2rem;
            color: #1a73e8 !important;
            display: inline-block;
            width: 100%;
            height: 100%;
            line-height: 40px;
            text-align: center;
        }

        @media (max-width: 992px) {
            .about-grid {
                grid-template-columns: 1fr;
                gap: 2rem;
            }

            .about-header h1 {
                font-size: 2.5rem;
            }

            .about-content h2,
            .values-section h2,
            .team-section h2 {
                font-size: 2rem;
            }
        }

        @media (max-width: 768px) {
            .about-header {
                margin-bottom: 3rem;
            }

            .about-header h1 {
                font-size: 2rem;
            }

            .about-content h2,
            .values-section h2,
            .team-section h2 {
                font-size: 1.8rem;
            }

            .team-image {
                width: 150px;
                height: 150px;
            }
        }

        /* Animation Classes */
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }

        .slide-up {
            animation: slideUp 0.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { 
                opacity: 0;
                transform: translateY(20px);
            }
            to { 
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <main class="container" style="padding: 4rem 0;">
        <div class="about-header">
            <h1 class="fade-in">About ConsumePure</h1>
            <p class="slide-up">
                Your trusted source for accurate medicine information and healthcare guidance.
            </p>
        </div>
        
        <div class="about-grid">
            <div class="about-content slide-up">
                <h2>Our Mission</h2>
                <p>
                    At ConsumePure, we believe that everyone deserves access to reliable, easy-to-understand information about 
                    their medications. Our mission is to empower individuals to make informed decisions about their health by 
                    providing accurate, up-to-date information about medicines and healthcare.
                </p>
                <p>
                    We work with healthcare professionals, pharmacists, and medical experts to ensure that all information 
                    on our platform is verified and trustworthy. Our commitment to accuracy and transparency makes us a 
                    reliable resource for both patients and healthcare providers.
                </p>
            </div>
            
            <div class="about-image slide-up">
                <img src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&auto=format&fit=crop&q=60" 
                     alt="Healthcare professionals">
            </div>
        </div>
        
        <div class="values-section">
            <h2 class="fade-in">Our Values</h2>
            
            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="value-card slide-up">
                        <h3>Accuracy</h3>
                        <p>We ensure all medical information is verified by healthcare professionals and updated regularly.</p>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-3">
                    <div class="value-card slide-up" style="animation-delay: 0.1s;">
                        <h3>Accessibility</h3>
                        <p>Making medical information easily accessible and understandable for everyone.</p>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-3">
                    <div class="value-card slide-up" style="animation-delay: 0.2s;">
                        <h3>Privacy</h3>
                        <p>Your health information is private. We maintain strict security standards to protect your data.</p>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-3">
                    <div class="value-card slide-up" style="animation-delay: 0.3s;">
                        <h3>Support</h3>
                        <p>Providing reliable support through our expert chat system and comprehensive resources.</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="team-section">
            <h2 class="fade-in">Our Team</h2>
            
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="team-card slide-up">
                        <div class="team-image">
                            <img src="assets/images/sakshi.jpg" alt="Sakshi Patil">
                        </div>
                        <h3>Sakshi Patil</h3>
                        <p>Back-end Developer</p>
                        <div class="social-links">
                            <a href="https://www.linkedin.com/in/sakshi-patil-617803220/" target="_blank" title="LinkedIn">
                                <i class="fab fa-linkedin"></i>
                            </a>
                            <a href="https://medium.com/@patilsakshi2615" target="_blank" title="Medium">
                                <i class="fab fa-medium"></i>
                            </a>
                            <a href="mailto:patilsakshi2615@gmail.com" title="Gmail">
                                <i class="fas fa-envelope"></i>
                            </a>
                            <a href="https://github.com/The-Sksh" target="_blank" title="GitHub">
                                <i class="fab fa-github"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="team-card slide-up" >
                        <div class="team-image">
                            <img src="assets/images/rishita.jpg" alt="Rishita Shah">
                        </div>
                        <h3>Rishita Shah</h3>
                        <p>Front-end Developer</p>
                        <div class="social-links">
                            <a href="https://www.linkedin.com/in/rishita-shah25/" target="_blank" title="LinkedIn">
                                <i class="fab fa-linkedin"></i>
                            </a>
                            <a href="https://rishitashah.medium.com/" target="_blank" title="Medium">
                                <i class="fab fa-medium"></i>
                            </a>
                            <a href="mailto:rishitashah6263@gmail.com" title="Gmail">
                                <i class="fas fa-envelope"></i>
                            </a>
                            <a href="https://github.com/RishitaShahh" target="_blank" title="GitHub">
                                <i class="fab fa-github"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add animation classes to elements when they come into view
        document.addEventListener('DOMContentLoaded', function() {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('fade-in');
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.1
            });

            document.querySelectorAll('.slide-up').forEach((el) => observer.observe(el));
        });
    </script>
</body>
</html> 