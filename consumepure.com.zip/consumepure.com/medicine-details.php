<?php
require_once "config/database.php";
session_start();

// Check if medicine ID is provided
if(!isset($_GET["id"]) || empty($_GET["id"])){
    header("location: search.php");
    exit;
}

$medicine = null;
$id = $_GET["id"];

// Get medicine details
$sql = "SELECT * FROM medicines WHERE id = ?";
if($stmt = mysqli_prepare($conn, $sql)){
    mysqli_stmt_bind_param($stmt, "i", $id);
    
    if(mysqli_stmt_execute($stmt)){
        $result = mysqli_stmt_get_result($stmt);
        
        if(mysqli_num_rows($result) == 1){
            $medicine = mysqli_fetch_array($result);
        } else{
            header("location: search.php");
            exit;
        }
    } else{
        echo "Oops! Something went wrong. Please try again later.";
    }
    
    mysqli_stmt_close($stmt);
}
?>

<?php include 'includes/header.php'; ?>

<main class="container" style="padding: 4rem 0;">
    <?php if($medicine): ?>
        <div class="medicine-details">
            <div class="card">
                <h1 style="color: var(--primary-blue); margin-bottom: 2rem;">
                    <?php echo htmlspecialchars($medicine['name']); ?>
                </h1>
                
                <div class="details-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                    <div class="detail-section">
                        <h3>Description</h3>
                        <p style="margin: 1rem 0;"><?php echo nl2br(htmlspecialchars($medicine['description'])); ?></p>
                    </div>
                    
                    <div class="detail-section">
                        <h3>Side Effects</h3>
                        <p style="margin: 1rem 0;"><?php echo nl2br(htmlspecialchars($medicine['side_effects'])); ?></p>
                    </div>
                    
                    <div class="detail-section">
                        <h3>Dosage</h3>
                        <p style="margin: 1rem 0;"><?php echo nl2br(htmlspecialchars($medicine['dosage'])); ?></p>
                    </div>
                </div>
                
                <div style="margin-top: 2rem;">
                    <a href="search.php" class="btn-primary">Back to Search</a>
                </div>
            </div>
        </div>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?> 