<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

try {
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('User not logged in');
    }

    $user_id = $_SESSION['user_id'];
    
    // Get chat history
    $query = "SELECT * FROM medical_chat_conversations 
              WHERE user_id = ? 
              ORDER BY created_at DESC 
              LIMIT 10";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $chat_history = [];
    while ($row = $result->fetch_assoc()) {
        $chat_history[] = [
            'id' => $row['id'],
            'message' => $row['user_message'],
            'response' => $row['bot_response'],
            'timestamp' => $row['created_at']
        ];
    }
    
    echo json_encode([
        'status' => 'success',
        'chat_history' => $chat_history
    ]);

} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?> 