<?php
// Error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Simple response database
$responses = [
    'greetings' => [
        'hi' => 'Hello! How can I help you with your health today?',
        'hello' => 'Hi there! I\'m here to assist with your health concerns.',
        'hey' => 'Hey! How can I help you today?'
    ],
    'symptoms' => [
        'headache' => 'For headaches, you can try: 1. Rest in a quiet, dark room 2. Drink plenty of water 3. Take a pain reliever like paracetamol Would you like more specific advice?',
        'fever' => 'For fever: 1. Rest and stay hydrated 2. Take paracetamol as directed 3. Monitor your temperature When did your fever start?',
        'cough' => 'For cough: 1. Stay hydrated 2. Use cough drops 3. Consider cough syrup Is it a dry or wet cough?',
        'tired' => 'For fatigue: 1. Ensure adequate sleep 2. Stay hydrated 3. Consider vitamin supplements How long have you been feeling tired?'
    ],
    'ayurvedic' => [
        'ashwagandha' => 'Ashwagandha: Uses: Stress relief, energy boost, sleep improvement. Dosage: 500mg-1g twice daily. Side effects: Generally safe, may cause drowsiness. Home remedy: Mix with warm milk at bedtime.',
        'turmeric' => 'Turmeric: Uses: Anti-inflammatory, antioxidant, immunity boost. Dosage: 500mg-1g daily. Side effects: May cause stomach upset. Home remedy: Golden milk (turmeric + milk + honey).',
        'triphala' => 'Triphala: Uses: Digestion, constipation, detoxification. Dosage: 500mg-1g at bedtime. Side effects: May cause loose stools initially. Home remedy: Mix with warm water.',
        'neem' => 'Neem: Uses: Skin problems, blood purification, immunity. Dosage: 500mg daily. Side effects: May cause stomach upset. Home remedy: Neem water for skin washing.',
        'tulsi' => 'Tulsi: Uses: Respiratory health, immunity, stress relief. Dosage: 2-3 leaves daily. Side effects: Rare. Home remedy: Tulsi tea for cold and cough.'
    ],
    'allopathic' => [
        'paracetamol' => 'Paracetamol: Uses: Fever, mild to moderate pain. Dosage: 500mg every 4-6 hours. Max: 4g per day. Side effects: Rare, may cause liver damage in overdose.',
        'ibuprofen' => 'Ibuprofen: Uses: Pain, inflammation, fever. Dosage: 200-400mg every 6-8 hours. Side effects: Stomach upset, heartburn. Avoid if: Stomach issues.',
        'cetirizine' => 'Cetirizine: Uses: Allergies, hay fever, hives. Dosage: 10mg once daily. Side effects: Drowsiness, dry mouth. Avoid: Alcohol.',
        'omeprazole' => 'Omeprazole: Uses: Acid reflux, heartburn. Dosage: 20mg once daily. Side effects: Headache, diarrhea. Take: Before meals.',
        'amoxicillin' => 'Amoxicillin: Uses: Bacterial infections. Dosage: 250-500mg every 8 hours. Side effects: Diarrhea, rash. Important: Complete full course.'
    ],
    'homeopathic' => [
        'arnica' => 'Arnica: Uses: Bruises, sprains, muscle pain. Potency: 6X or 30C. Side effects: Rare, may cause skin irritation. Avoid: On broken skin.',
        'belladonna' => 'Belladonna: Uses: Fever, headache, inflammation. Potency: 6X or 30C. Side effects: Rare, may cause dry mouth. Use: Under supervision.',
        'nux vomica' => 'Nux Vomica: Uses: Indigestion, nausea, constipation. Potency: 6X or 30C. Side effects: Rare. Take: Before meals.',
        'pulsatilla' => 'Pulsatilla: Uses: Cold, cough, menstrual problems. Potency: 6X or 30C. Side effects: Rare. Best for: Emotional symptoms.',
        'rhus tox' => 'Rhus Tox: Uses: Joint pain, stiffness, skin rashes. Potency: 6X or 30C. Side effects: Rare. Use: For rheumatic complaints.'
    ],
    'home_remedies' => [
        'cold' => 'For cold: 1. Ginger tea with honey 2. Steam inhalation 3. Turmeric milk 4. Rest and hydration',
        'cough' => 'For cough: 1. Honey and lemon 2. Tulsi tea 3. Ginger juice 4. Warm water gargles',
        'fever' => 'For fever: 1. Coriander seed tea 2. Fenugreek water 3. Basil leaf juice 4. Cold compress',
        'headache' => 'For headache: 1. Peppermint oil massage 2. Cold compress 3. Ginger tea 4. Adequate rest',
        'indigestion' => 'For indigestion: 1. Fennel seeds 2. Ginger tea 3. Buttermilk 4. Walking after meals'
    ],
    'purchase' => [
        'where' => 'You can purchase this medicine at: 1. Your nearest pharmacy 2. Medical stores 3. Online pharmacies (with prescription) 4. Hospital pharmacies',
        'how' => 'To purchase this medicine: 1. Visit a licensed pharmacy 2. Present your prescription if required 3. Check the expiry date 4. Verify the dosage',
        'price' => 'Medicine prices may vary. Please check with your local pharmacy for current pricing.',
        'online' => 'For online purchase: 1. Use only licensed online pharmacies 2. Always check for prescription requirements 3. Verify the pharmacy\'s credentials 4. Look for secure payment options'
    ],
    'general' => [
        'default' => 'I\'m here to help with your health concerns. You can ask me about: - Symptoms - Medicines (Ayurvedic, Allopathic, Homeopathic) - Home remedies - General health advice What would you like to know?',
        'unknown' => 'I\'m not sure about that. Could you please provide more details or ask about something else?'
    ],
    'general_medicines' => [
        'combiflam' => 'Combiflam: Uses: Pain relief, fever, inflammation. Composition: Ibuprofen 400mg + Paracetamol 325mg. Dosage: 1 tablet every 6-8 hours. Side effects: Stomach upset, heartburn, nausea. Avoid if: Stomach ulcers, kidney problems. Symptoms it treats: Headache, toothache, muscle pain, joint pain, fever.',
        'dulcoflex' => 'Dulcoflex: Uses: Constipation relief. Composition: Bisacodyl 5mg. Dosage: 1-2 tablets at bedtime. Side effects: Abdominal cramps, diarrhea. Avoid if: Abdominal pain, nausea, vomiting. Symptoms it treats: Constipation, irregular bowel movements.',
        'vicks action 500' => 'Vicks Action 500: Uses: Cold and flu symptoms. Composition: Paracetamol 500mg + Phenylephrine 5mg + Caffeine 30mg. Dosage: 1 tablet every 4-6 hours. Side effects: Drowsiness, dry mouth. Avoid if: High blood pressure, heart problems. Symptoms it treats: Fever, headache, body ache, nasal congestion, sore throat.'
    ],
    'migraine' => [
        'ayurvedic' => 'Ayurvedic treatments for migraine: 1. Shirodhara (oil treatment) 2. Nasya (nasal therapy) 3. Herbs: Brahmi, Ashwagandha, Jatamansi 4. Yoga and meditation 5. Dietary changes: Avoid processed foods, caffeine',
        'allopathic' => 'Allopathic treatments for migraine: 1. Pain relievers: Paracetamol, Ibuprofen 2. Triptans: Sumatriptan, Rizatriptan 3. Anti-nausea: Metoclopramide 4. Preventive: Propranolol, Topiramate 5. CGRP inhibitors',
        'homeopathic' => 'Homeopathic remedies for migraine: 1. Belladonna: Throbbing headache 2. Natrum Mur: Headache with nausea 3. Iris Versicolor: Visual disturbances 4. Sanguinaria: Right-sided headache 5. Spigelia: Left-sided headache',
        'home_remedies' => 'Home remedies for migraine: 1. Cold compress on forehead 2. Ginger tea 3. Peppermint oil massage 4. Stay hydrated 5. Dark, quiet room rest 6. Regular sleep schedule 7. Avoid trigger foods 8. Regular exercise'
    ]
];

try {
    // Get the message
    $data = json_decode(file_get_contents('php://input'), true);
    $message = strtolower(trim($data['message'] ?? ''));
    
    if (empty($message)) {
        throw new Exception('Empty message received');
    }

    // Process the message
    $response = '';
    
    // Check for medicine type preference
    if (strpos($message, 'ayurvedic') !== false) {
        $response = 'Here are some common Ayurvedic medicines I can tell you about: ' . 
                   implode(', ', array_keys($responses['ayurvedic'])) . 
                   '. Please ask about any specific medicine for detailed information.';
    } elseif (strpos($message, 'allopathic') !== false) {
        $response = 'Here are some common Allopathic medicines I can tell you about: ' . 
                   implode(', ', array_keys($responses['allopathic'])) . 
                   '. Please ask about any specific medicine for detailed information.';
    } elseif (strpos($message, 'homeopathic') !== false) {
        $response = 'Here are some common Homeopathic medicines I can tell you about: ' . 
                   implode(', ', array_keys($responses['homeopathic'])) . 
                   '. Please ask about any specific medicine for detailed information.';
    }
    
    // Check purchase-related queries
    if (empty($response)) {
        $purchaseKeywords = ['buy', 'purchase', 'where to get', 'where can i get', 'available at', 'price', 'cost', 'shop', 'store', 'pharmacy', 'how to get', 'how can i get'];
        foreach ($purchaseKeywords as $keyword) {
            if (strpos($message, $keyword) !== false) {
                if (strpos($message, 'online') !== false) {
                    $response = $responses['purchase']['online'];
                } elseif (strpos($message, 'price') !== false || strpos($message, 'cost') !== false) {
                    $response = $responses['purchase']['price'];
                } elseif (strpos($message, 'how') !== false) {
                    $response = $responses['purchase']['how'];
                } else {
                    $response = $responses['purchase']['where'];
                }
                break;
            }
        }
    }
    
    // Check home remedies
    if (empty($response)) {
        foreach ($responses['home_remedies'] as $key => $value) {
            if (strpos($message, $key) !== false) {
                $response = $value;
                break;
            }
        }
    }
    
    // Check greetings
    if (empty($response)) {
        foreach ($responses['greetings'] as $key => $value) {
            if (strpos($message, $key) !== false) {
                $response = $value;
                break;
            }
        }
    }
    
    // Check symptoms
    if (empty($response)) {
        foreach ($responses['symptoms'] as $key => $value) {
            if (strpos($message, $key) !== false) {
                $response = $value;
                break;
            }
        }
    }
    
    // Check all medicine types
    if (empty($response)) {
        $allMedicines = array_merge(
            $responses['ayurvedic'],
            $responses['allopathic'],
            $responses['homeopathic']
        );
        foreach ($allMedicines as $key => $value) {
            if (strpos($message, $key) !== false) {
                $response = $value;
                break;
            }
        }
    }
    
    // Check general medicines
    if (empty($response)) {
        foreach ($responses['general_medicines'] as $key => $value) {
            if (strpos($message, $key) !== false) {
                $response = $value;
                break;
            }
        }
    }
    
    // Check migraine treatments
    if (empty($response)) {
        if (strpos($message, 'migraine') !== false) {
            if (strpos($message, 'ayurvedic') !== false) {
                $response = $responses['migraine']['ayurvedic'];
            } elseif (strpos($message, 'allopathic') !== false) {
                $response = $responses['migraine']['allopathic'];
            } elseif (strpos($message, 'homeopathic') !== false) {
                $response = $responses['migraine']['homeopathic'];
            } elseif (strpos($message, 'home remedy') !== false || strpos($message, 'natural') !== false) {
                $response = $responses['migraine']['home_remedies'];
            } else {
                $response = 'For migraine, I can provide information about: 1. Ayurvedic treatments 2. Allopathic medicines 3. Homeopathic remedies 4. Home remedies Which would you like to know about?';
            }
        }
    }
    
    // Default response
    if (empty($response)) {
        $response = $responses['general']['default'];
    }

    // Return the response
    echo json_encode([
        'response' => $response,
        'status' => 'success'
    ]);

} catch (Exception $e) {
    // Return error response
    echo json_encode([
        'response' => 'I\'m having trouble processing your request. Please try again.',
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?> 