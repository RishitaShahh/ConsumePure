<?php
session_start();
include 'includes/header.php'; 
?>

<main>
    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Welcome to ConsumePure</h1>
                <p class="subtitle">Your trusted source for accurate medicine information</p>
                
                <div class="search-box">
                    <form action="search.php" method="GET">
                        <div class="search-wrapper">
                            <input type="text" name="query" id="medicineSearch" placeholder="Search for medicines..." required>
                            <button type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                    <div id="searchResults" class="search-results"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <div class="container">
            <h2>Why Choose ConsumePure?</h2>
            <div class="features-grid">
                <div class="feature-item">
                    <div class="icon-wrapper">
                        <i class="fas fa-pills"></i>
                    </div>
                    <h3>Comprehensive Database</h3>
                    <p>Access detailed information about thousands of medicines</p>
                </div>
                
                <div class="feature-item">
                    <div class="icon-wrapper">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <h3>Expert Guidance</h3>
                    <p>Get professional advice from healthcare experts</p>
                </div>
                
                <div class="feature-item">
                    <div class="icon-wrapper">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Verified Information</h3>
                    <p>All content is verified by medical professionals</p>
                </div>
                
                <div class="feature-item">
                    <div class="icon-wrapper">
                        <i class="fas fa-comments"></i>
                    </div>
                    <h3>24/7 Support</h3>
                    <p>Round-the-clock assistance for your queries</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Explore?</h2>
                <p>Start your journey to better health information today</p>
                <a href="https://www.google.com/search?q=medicines" class="cta-button" target="_blank">
                    Browse Medicines
                    <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>
    </section>
</main>

<style>
    /* Hero Section */
    .hero {
        background: linear-gradient(135deg, #e6f2ff 0%, #cce6ff 100%);
        color: #2c3e50;
        padding: 6rem 0;
        text-align: center;
    }

    .hero-content {
        max-width: 800px;
        margin: 0 auto;
    }

    .hero h1 {
        font-size: 3.5rem;
        margin-bottom: 1rem;
        font-weight: 700;
        color: #2c3e50;
    }

    .subtitle {
        font-size: 1.25rem;
        margin-bottom: 2rem;
        color: #4a6b8a;
    }

    /* Search Box */
    .search-box {
        max-width: 600px;
        margin: 0 auto;
    }

    .search-wrapper {
        display: flex;
        background: white;
        border-radius: 50px;
        padding: 0.5rem;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    }

    .search-wrapper input {
        flex: 1;
        border: none;
        padding: 1rem 1.5rem;
        font-size: 1.1rem;
        border-radius: 50px 0 0 50px;
        outline: none;
        color: #2c3e50;
    }

    .search-wrapper button {
        background: #4a90e2;
        color: white;
        border: none;
        padding: 1rem 2rem;
        border-radius: 50px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .search-wrapper button:hover {
        background: #357abd;
    }

    /* Features Section */
    .features {
        padding: 5rem 0;
        background: #f8f9fa;
    }

    .features h2 {
        text-align: center;
        font-size: 2.5rem;
        margin-bottom: 3rem;
        color: #2c3e50;
    }

    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 2rem;
        max-width: 1200px;
        margin: 0 auto;
    }

    .feature-item {
        background: white;
        padding: 2rem;
        border-radius: 15px;
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        border: 1px solid #e6f2ff;
    }

    .feature-item:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 30px rgba(74, 144, 226, 0.1);
    }

    .icon-wrapper {
        width: 80px;
        height: 80px;
        background: #e6f2ff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1.5rem;
    }

    .icon-wrapper i {
        font-size: 2rem;
        color: #4a90e2;
    }

    .feature-item h3 {
        font-size: 1.5rem;
        margin-bottom: 1rem;
        color: #2c3e50;
    }

    .feature-item p {
        color: #4a6b8a;
        line-height: 1.6;
    }

    /* CTA Section */
    .cta {
        background: linear-gradient(135deg, #e6f2ff 0%, #cce6ff 100%);
        color: #2c3e50;
        padding: 5rem 0;
        text-align: center;
    }

    .cta-content {
        max-width: 600px;
        margin: 0 auto;
    }

    .cta h2 {
        font-size: 2.5rem;
        margin-bottom: 1rem;
        color: #2c3e50;
    }

    .cta p {
        font-size: 1.2rem;
        margin-bottom: 2rem;
        color: #4a6b8a;
    }

    .cta-button {
        display: inline-flex;
        align-items: center;
        background: #4a90e2;
        color: white;
        padding: 1rem 2rem;
        border-radius: 50px;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .cta-button:hover {
        transform: translateY(-3px);
        background: #357abd;
        color: white;
    }

    .cta-button i {
        margin-left: 0.5rem;
        transition: transform 0.3s ease;
    }

    .cta-button:hover i {
        transform: translateX(5px);
    }

    /* Search Results */
    .search-results {
        position: absolute;
        width: 100%;
        background: white;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
        margin-top: 1rem;
        z-index: 1000;
        display: none;
        border: 1px solid #e6f2ff;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('medicineSearch');
    const searchResults = document.getElementById('searchResults');
    
    searchInput.addEventListener('input', function() {
        if (this.value.length > 2) {
            searchResults.style.display = 'block';
        } else {
            searchResults.style.display = 'none';
        }
    });

    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
            searchResults.style.display = 'none';
        }
    });
});
</script>

<?php include 'includes/footer.php'; ?>