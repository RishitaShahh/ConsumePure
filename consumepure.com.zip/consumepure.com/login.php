<?php
session_start();

// Check if the user is already logged in
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: index.php");
    exit;
}

// Include database connection
require_once "config/database.php";

$username = $password = "";
$username_err = $password_err = $login_err = $recaptcha_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate reCAPTCHA
    if(isset($_POST['g-recaptcha-response'])){
        $recaptcha_response = $_POST['g-recaptcha-response'];
        $secret_key = "6LczeCIrAAAAAL41J-TRVseYf9nGM4hLO32wHdFs";
        $verify_response = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret_key.'&response='.$recaptcha_response);
        $response_data = json_decode($verify_response);
        
        if(!$response_data->success){
            $recaptcha_err = "Please complete the reCAPTCHA verification.";
        }
    } else {
        $recaptcha_err = "Please complete the reCAPTCHA verification.";
    }

    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err) && empty($recaptcha_err)){
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            $param_username = $username;
            
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            session_start();
                            
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            
                            header("location: index.php");
                        } else{
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            mysqli_stmt_close($stmt);
        }
    }
    
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to ConsumePure - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        :root {
            --primary-blue: #007bff;
            --light-blue: #f8f9fa;
        }
        body {
            background-color: var(--light-blue);
        }
        .wrapper{ 
            width: 400px; 
            padding: 30px;
            margin: 0 auto;
            margin-top: 50px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary-blue);
            font-size: 2em;
            font-weight: bold;
        }
        .btn-primary {
            background-color: var(--primary-blue);
            border-color: var(--primary-blue);
        }
        .form-control:focus {
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="logo">ConsumePure</div>
        <h2 class="text-center mb-4">Welcome Back!</h2>
        <p class="text-center text-muted mb-4">Please login to access your account</p>

        <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group mb-3">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group mb-4">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group mb-4">
                <div class="g-recaptcha" data-sitekey="6LczeCIrAAAAAOZmVAYOxRMz-rtvWeXv3HQFThd8"></div>
                <?php if(!empty($recaptcha_err)): ?>
                    <span class="text-danger"><?php echo $recaptcha_err; ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group mb-4">
                <input type="submit" class="btn btn-primary w-100" value="Login">
            </div>
            <p class="text-center">New to ConsumePure? <a href="register.php">Create an account</a></p>
        </form>
    </div>    

    <script>
    // Custom styling for registration success
    function showRegistrationSuccess(message) {
        Swal.fire({
            icon: 'success',
            title: 'Welcome to ConsumePure!',
            text: message,
            confirmButtonColor: '#0d6efd',
            background: '#fff',
            customClass: {
                confirmButton: 'btn btn-primary btn-lg',
                title: 'text-success fw-bold'
            },
            showClass: {
                popup: 'animate__animated animate__fadeInDown'
            },
            hideClass: {
                popup: 'animate__animated animate__fadeOutUp'
            }
        });
    }

    // Custom styling for login success
    function showLoginSuccess(message) {
        Swal.fire({
            icon: 'success',
            title: 'Welcome Back!',
            text: message,
            confirmButtonColor: '#0d6efd',
            background: '#fff',
            timer: 2000,
            timerProgressBar: true,
            customClass: {
                confirmButton: 'btn btn-primary btn-lg',
                title: 'text-success fw-bold'
            },
            showClass: {
                popup: 'animate__animated animate__fadeInDown'
            },
            hideClass: {
                popup: 'animate__animated animate__fadeOutUp'
            }
        }).then((result) => {
            window.location.href = 'dashboard.php'; // Redirect after alert
        });
    }

    // Custom styling for error messages
    function showError(title, message) {
        Swal.fire({
            icon: 'error',
            title: title,
            text: message,
            confirmButtonColor: '#dc3545',
            background: '#fff',
            customClass: {
                confirmButton: 'btn btn-danger btn-lg',
                title: 'text-danger fw-bold'
            }
        });
    }

    // Implementation in your page
    <?php if(isset($_SESSION['success_msg'])): ?>
        showRegistrationSuccess('<?php echo $_SESSION['success_msg']; ?>');
        <?php unset($_SESSION['success_msg']); ?>
    <?php endif; ?>

    <?php if(isset($_SESSION['login_success'])): ?>
        showLoginSuccess('<?php echo $_SESSION['login_success']; ?>');
        <?php unset($_SESSION['login_success']); ?>
    <?php endif; ?>

    <?php if(isset($_SESSION['error_msg'])): ?>
        showError('Error!', '<?php echo $_SESSION['error_msg']; ?>');
        <?php unset($_SESSION['error_msg']); ?>
    <?php endif; ?>
    </script>
</body>
</html>