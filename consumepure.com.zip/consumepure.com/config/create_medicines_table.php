<?php
require_once "database.php";

// Drop the medicines table if it exists
$sql = "DROP TABLE IF EXISTS medicines";
if(mysqli_query($conn, $sql)) {
    echo "Old medicines table dropped successfully.<br>";
} else {
    echo "Error dropping medicines table: " . mysqli_error($conn) . "<br>";
}

// Create new medicines table with correct structure
$sql = "CREATE TABLE `medicines` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `description` text NOT NULL,
    `side_effects` text NOT NULL,
    `dosage` text NOT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if(mysqli_query($conn, $sql)) {
    echo "New medicines table created successfully with correct structure.<br>";
    
    // Insert medicine data
    $medicine_data = file_get_contents('medicines_data.sql');
    if(mysqli_multi_query($conn, $medicine_data)) {
        echo "Medicine data inserted successfully.";
    } else {
        echo "Error inserting medicine data: " . mysqli_error($conn);
    }
} else {
    echo "Error creating medicines table: " . mysqli_error($conn);
}
?> 