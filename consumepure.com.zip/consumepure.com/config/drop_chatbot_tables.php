<?php
require_once "database.php";

// Drop chat_history table if it exists
$sql = "DROP TABLE IF EXISTS `chat_history`";
if(mysqli_query($conn, $sql)) {
    echo "Chat history table dropped successfully.";
} else {
    echo "Error dropping chat history table: " . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);
?> 