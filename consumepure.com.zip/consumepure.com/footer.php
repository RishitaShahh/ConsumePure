<div class="contact-info">
    <p>Contact us: <a href="tel:7974928294">+91 7974928294</a></p>
</div> 