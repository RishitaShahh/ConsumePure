<?php
require_once "config/database.php";
session_start();

// Get blog posts
$blog_posts = array(
    array(
        'title' => 'When Not to Take Antibiotics',
        'excerpt' => 'Antibiotics are powerful medicines, but they\'re not the solution for all illnesses. Learn when to avoid them.',
        'author' => 'Dr. Sarah Johnson',
        'date' => '2024-03-15',
        'image' => 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&auto=format&fit=crop&q=60',
        'category' => 'Medicine Safety'
    ),
    array(
        'title' => 'How to Store Medicines Safely',
        'excerpt' => 'Proper medicine storage is crucial for maintaining their effectiveness and safety. Follow these essential guidelines.',
        'author' => 'Dr. Michael Chen',
        'date' => '2024-03-10',
        'image' => 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&auto=format&fit=crop&q=60',
        'category' => 'Medicine Safety'
    ),
    array(
        'title' => 'Understanding Medicine Labels',
        'excerpt' => 'Medicine labels contain vital information. Learn how to read and understand them properly.',
        'author' => 'Dr. Emily Wilson',
        'date' => '2024-03-05',
        'image' => 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=60',
        'category' => 'Medicine Education'
    ),
    array(
        'title' => 'Common Drug Interactions to Avoid',
        'excerpt' => 'Some medications don\'t mix well together. Learn about common interactions and how to avoid them.',
        'author' => 'Dr. James Martinez',
        'date' => '2024-03-01',
        'image' => 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&auto=format&fit=crop&q=60',
        'category' => 'Medicine Safety'
    ),
    array(
        'title' => 'The Importance of Regular Health Check-ups',
        'excerpt' => 'Regular health check-ups are essential for maintaining good health and preventing diseases.',
        'author' => 'Dr. Lisa Thompson',
        'date' => '2024-02-25',
        'image' => 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=60',
        'category' => 'Health Tips'
    ),
    array(
        'title' => 'Understanding Your Prescription',
        'excerpt' => 'Learn how to read and understand your prescription to ensure proper medication use.',
        'author' => 'Dr. Robert Wilson',
        'date' => '2024-02-20',
        'image' => 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&auto=format&fit=crop&q=60',
        'category' => 'Medicine Education'
    )
);

// Get selected category from URL and decode it
$selected_category = isset($_GET['category']) ? urldecode($_GET['category']) : '';

// Filter posts by category if one is selected
$filtered_posts = $blog_posts;
if (!empty($selected_category)) {
    $filtered_posts = array_filter($blog_posts, function($post) use ($selected_category) {
        return $post['category'] === $selected_category;
    });
}

// Get unique categories
$categories = array_unique(array_column($blog_posts, 'category'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog - ConsumePure</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-text: #2c3e50;
            --light-text: #7f8c8d;
            --border-color: #e0e0e0;
            --heading-blue: #1a73e8;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .blog-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
        }

        .blog-header {
            text-align: center;
            margin-bottom: 3rem;
            position: relative;
        }

        .blog-header h1 {
            color: var(--heading-blue);
            font-weight: 700;
            margin-bottom: 1rem;
            position: relative;
            display: inline-block;
            font-size: 2.5rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .blog-header h1:after {
            content: '';
            position: absolute;
            width: 50px;
            height: 3px;
            background: var(--heading-blue);
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            border-radius: 3px;
        }

        .blog-header p {
            color: var(--light-text);
            font-size: 1.1rem;
            max-width: 600px;
            margin: 0 auto;
        }

        .blog-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .blog-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(26, 115, 232, 0.1);
        }

        .blog-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(26, 115, 232, 0.2);
            border-color: rgba(26, 115, 232, 0.3);
        }

        .blog-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }

        .blog-content {
            padding: 1.5rem;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .blog-category {
            display: inline-block;
            padding: 0.3rem 1rem;
            background: rgba(26, 115, 232, 0.1);
            color: var(--heading-blue);
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            margin-bottom: 1rem;
            text-transform: uppercase;
        }

        .blog-title {
            color: var(--heading-blue);
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 1rem;
            line-height: 1.4;
            transition: color 0.3s ease;
        }

        .blog-title:hover {
            color: #1557b0;
        }

        .blog-excerpt {
            color: var(--light-text);
            margin-bottom: 1.5rem;
            flex-grow: 1;
        }

        .blog-meta {
            display: flex;
            align-items: center;
            color: var(--light-text);
            font-size: 0.9rem;
            margin-top: auto;
        }

        .blog-meta span {
            margin-right: 1rem;
            display: flex;
            align-items: center;
        }

        .blog-meta i {
            color: var(--heading-blue);
            margin-right: 0.5rem;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 3rem;
        }

        .page-link {
            color: var(--heading-blue);
            border: none;
            padding: 0.5rem 1rem;
            margin: 0 0.3rem;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .page-link:hover {
            background: var(--heading-blue);
            color: white;
        }

        .page-item.active .page-link {
            background: var(--heading-blue);
            color: white;
        }

        .search-box {
            max-width: 500px;
            margin: 0 auto 3rem;
            position: relative;
        }

        .search-input {
            width: 100%;
            padding: 1rem 1.5rem;
            border: 2px solid var(--border-color);
            border-radius: 30px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .search-input:focus {
            border-color: var(--heading-blue);
            box-shadow: 0 0 0 0.2rem rgba(26, 115, 232, 0.25);
            outline: none;
        }

        .search-icon {
            position: absolute;
            right: 1.5rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--heading-blue);
        }

        .category-filter {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            justify-content: center;
            margin-bottom: 2rem;
        }

        .category-btn {
            padding: 0.5rem 1.5rem;
            border: 2px solid var(--heading-blue);
            background: none;
            color: var(--heading-blue);
            border-radius: 30px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.9rem;
        }

        .category-btn:hover,
        .category-btn.active {
            background: var(--heading-blue);
            color: white;
            transform: translateY(-2px);
        }

        .read-more-btn {
            display: inline-block;
            padding: 0.6rem 1.5rem;
            background: var(--heading-blue);
            color: white;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            margin-top: 1rem;
            text-align: center;
            border: 2px solid var(--heading-blue);
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

        .read-more-btn:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: white;
            z-index: -1;
            transform: scaleX(0);
            transform-origin: right;
            transition: transform 0.3s ease;
        }

        .read-more-btn:hover {
            color: var(--heading-blue);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(26, 115, 232, 0.3);
        }

        .read-more-btn:hover:before {
            transform: scaleX(1);
            transform-origin: left;
        }

        .read-more-btn i {
            margin-left: 0.5rem;
            transition: transform 0.3s ease;
        }

        .read-more-btn:hover i {
            transform: translateX(3px);
        }

        @media (max-width: 768px) {
            .blog-container {
                padding: 1rem;
            }

            .blog-grid {
                grid-template-columns: 1fr;
            }

            .blog-header h1 {
                font-size: 2rem;
            }

            .search-box {
                margin: 0 1rem 2rem;
            }

            .category-filter {
                padding: 0 1rem;
            }

            .read-more-btn {
                padding: 0.5rem 1.2rem;
                font-size: 0.9rem;
            }
        }

        /* Animation Classes */
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }

        .slide-up {
            animation: slideUp 0.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { 
                opacity: 0;
                transform: translateY(20px);
            }
            to { 
                opacity: 1;
                transform: translateY(0);
            }
        }

        .category-tabs {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-bottom: 3rem;
            flex-wrap: wrap;
        }

        .category-tab {
            padding: 0.8rem 1.5rem;
            background: white;
            color: var(--heading-blue);
            border: 2px solid var(--heading-blue);
            border-radius: 30px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            z-index: 1;
            min-width: 150px;
            text-align: center;
        }

        .category-tab:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--heading-blue);
            z-index: -1;
            transform: scaleX(0);
            transform-origin: right;
            transition: transform 0.3s ease;
        }

        .category-tab:hover {
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(26, 115, 232, 0.3);
        }

        .category-tab:hover:before {
            transform: scaleX(1);
            transform-origin: left;
        }

        .category-tab.active {
            background: var(--heading-blue);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(26, 115, 232, 0.3);
        }

        .category-tab.active:before {
            transform: scaleX(1);
        }

        @media (max-width: 768px) {
            .category-tabs {
                gap: 0.5rem;
                padding: 0 1rem;
            }

            .category-tab {
                padding: 0.6rem 1rem;
                min-width: 120px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <main class="container" style="padding: 4rem 0;">
        <div class="blog-header" style="text-align: center; margin-bottom: 4rem;">
            <h1 style="color: var(--heading-blue);">Health Tips & Articles</h1>
            <p style="max-width: 600px; margin: 1rem auto;">
                Stay informed with the latest health information and medicine safety tips from our expert healthcare professionals.
            </p>
        </div>
        
        <div class="blog-categories" style="margin-bottom: 3rem;">
            <div class="category-tabs">
                <a href="?category=" class="category-tab <?php echo empty($selected_category) ? 'active' : ''; ?>">
                    All Posts
                </a>
                <?php foreach ($categories as $category): ?>
                    <a href="?category=<?php echo urlencode($category); ?>" 
                       class="category-tab <?php echo $selected_category === $category ? 'active' : ''; ?>">
                        <?php echo htmlspecialchars($category); ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        
        <?php if (empty($filtered_posts)): ?>
            <div style="text-align: center; padding: 2rem;">
                <p style="color: #666; font-size: 1.2rem;">No posts found in this category.</p>
            </div>
        <?php else: ?>
            <div class="blog-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 2rem;">
                <?php foreach($filtered_posts as $index => $post): ?>
                    <article class="card">
                        <div style="position: relative; padding-bottom: 60%; overflow: hidden; border-radius: 8px 8px 0 0;">
                            <img src="<?php echo htmlspecialchars($post['image']); ?>" 
                                 alt="<?php echo htmlspecialchars($post['title']); ?>"
                                 style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover;">
                        </div>
                        
                        <div style="padding: 1.5rem;">
                            <span class="category" style="background-color: var(--light-blue); color: var(--primary-blue); 
                                                        padding: 0.25rem 0.75rem; border-radius: 1rem; font-size: 0.875rem;">
                                <?php echo htmlspecialchars($post['category']); ?>
                            </span>
                            
                            <h2 style="margin: 1rem 0; font-size: 1.5rem;">
                                <?php echo htmlspecialchars($post['title']); ?>
                            </h2>
                            
                            <p style="margin-bottom: 1rem; color: #666;">
                                <?php echo htmlspecialchars($post['excerpt']); ?>
                            </p>
                            
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1.5rem;">
                                <span style="color: #666; font-size: 0.875rem;">
                                    By <?php echo htmlspecialchars($post['author']); ?>
                                </span>
                                <span style="color: #666; font-size: 0.875rem;">
                                    <?php echo date('M j, Y', strtotime($post['date'])); ?>
                                </span>
                            </div>
                            
                            <a href="blog-detail.php?id=<?php echo $index; ?>" class="read-more-btn">
                                Read More <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html> 